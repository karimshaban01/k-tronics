# K-TRONICS Wi-Fi Voucher Acquisition System

Self-service portal where a hotspot customer chooses a package, enters their name and
phone number, and receives an unused pfSense voucher from stock that an administrator
imported. No online payment is taken — the package price is recorded, not charged.

Plain PHP 8.1+ and MySQL/MariaDB. No framework, no Composer packages.

```
public/            ← the ONLY folder the web server should expose
  index.php          front controller and routes
  assets/            css, js, brand-logo.png
app/
  Controllers/       PortalController, AuthController, AdminController, ImportController
  Services/          CsvImportService, VoucherAllocator, PhoneNormalizer, AuditLogger
  Core/              Config, Database (PDO), Router, View, Session, Csrf, Crypto, RateLimiter, Lang
  Views/             portal/, admin/, layouts/
  Lang/              sw.php (Kiswahili, default), en.php
config/config.example.php
database/schema.sql, nginx.conf.example
bin/               install, create-admin, generate-keys, purge-old-data
storage/imports    temporary uploads (not web-accessible, auto-deleted)
storage/logs       PHP error log
```

## Requirements

- PHP 8.1 or newer with `pdo_mysql`, `sodium`, `mbstring` (all standard).
- MySQL 5.7+/8 or MariaDB 10.3+ (InnoDB). MySQL 8 / MariaDB 10.6+ is recommended
  for `SKIP LOCKED`; on older servers set `db.skip_locked` to `false`.
- Apache (mod_rewrite) or nginx + PHP-FPM. HTTPS strongly recommended.

## Install

1. Copy the folder to the server, e.g. `/var/www/ktronics-voucher`.
2. Create a database and user:
   ```sql
   CREATE DATABASE ktronics CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'ktronics'@'localhost' IDENTIFIED BY 'a-strong-password';
   GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES ON ktronics.* TO 'ktronics'@'localhost';
   ```
3. `cp config/config.example.php config/config.php` and edit it:
   database credentials, `portal.return_url`, `portal.return_hosts`, `app.base_url`.
4. `php bin/generate-keys.php` → paste both keys into `config.php` → **back the keys up**.
   Without `encryption_key`, stored voucher codes cannot be decrypted.
5. `php bin/install.php` → creates the tables, the four default packages and the first owner account.
6. Make storage writable by the web server user:
   `chown -R www-data storage && chmod 700 storage/imports`
7. Point the web server's document root at `public/` (see `database/nginx.conf.example`;
   for Apache, `public/.htaccess` is included). On shared hosting where you cannot change
   the document root, the root `.htaccess` forwards to `public/` and blocks the other folders.
8. Sign in at `/admin/login`.

## Connecting to the pfSense captive portal

1. **Let unauthenticated users reach this site**: Services → Captive Portal → (zone) →
   *Allowed Hostnames* (or *Allowed IP Addresses*) → add the voucher site's hostname/IP.
2. **Link from the portal page**: in the custom portal HTML add a button such as
   ```html
   <a href="http://vocha.ktronics.local/?return=http://10.0.0.1:8002/index.php?zone=ktronics">Pata vocha</a>
   ```
   The `return` URL is only accepted if its host is listed in `portal.return_hosts`;
   otherwise `portal.return_url` is used. The customer copies the code, taps
   **Rudi kwenye portal**, pastes it and taps *Unganisha*. The app never logs anyone in itself.
3. **Map rolls to packages**: in pfSense each voucher roll has a fixed *minutes per ticket*.
   Create one roll per package (e.g. 1440 min = daily, 2880 = 2 days, 10080 = weekly,
   43200 = 30 days), export each roll, and import it here into the matching package.
   The roll number in the file says nothing about its duration — the import form makes the
   admin confirm the mapping every time.

## Admin features

| Page | Who | What |
|---|---|---|
| Dashboard | all | issued today / 7 days / total, stock per package (low < 20 highlighted), latest requests |
| Stock & rolls | all (enable/disable: owner) | per-package and per-roll counts; disabling a roll stops issuing from it |
| Import roll | all | upload → preview (rows, new, duplicates, rejected with line numbers, masked samples) → confirm |
| Issued vouchers | all (Show code: owner) | search by name/phone/package/status/date; codes masked; "Show" is audit-logged |
| Packages | all (edit: owner) | labels (sw/en), price, duration, order, visible/hidden, add new |
| Admin users | owner | add owners/operators, disable accounts |
| Audit log | owner | logins, failed logins, imports, roll changes, package edits, code reveals |
| My account | all | change password |

Extra admins can also be created on the command line:
`php bin/create-admin.php "Jina Kamili" mtu@ktronics.co.tz operator`

## How issuance stays safe

- One InnoDB transaction per request: create acquisition → lock one `available` voucher of the
  **same package** from an **active** roll (`SELECT … FOR UPDATE [SKIP LOCKED]`) → mark it
  issued with a guarded `UPDATE … WHERE status='available'` → link it to the acquisition.
- `acquisitions.voucher_id` is UNIQUE, so the database itself rejects a double issue.
- Each form load carries a `request_token`; double taps and browser resubmits return the
  same voucher instead of a second one.
- An exhausted package shows *Zimeisha / Sold out*, cannot be selected, and is never
  substituted with another package's code. The failed request is recorded as `out_of_stock`.
- Deadlocks/lock timeouts are retried automatically (up to 4 attempts).

## Security and privacy

- PDO prepared statements everywhere; all output escaped; strict Content-Security-Policy
  (no inline scripts).
- Voucher codes encrypted at rest (libsodium secretbox); duplicates detected via an HMAC of the
  code (`UNIQUE code_hash`); admin lists show only `ab••••yz`.
- Codes never appear in URLs, logs or the audit log. The result page sends `no-store` and
  `no-referrer`, and is only viewable in the browser session that received the voucher.
- Admin: `password_hash`, session ID regenerated at login, idle timeout, CSRF tokens on every
  form, login throttling per IP and per email, owner/operator roles.
- Customer abuse limits (in `config.php`): requests per IP per 10 minutes, vouchers per phone
  per 24 hours. Because issuance is free, keep these on.
- Uploads: `.csv`/`.txt` only, size-limited, stored outside `public/` with a random name,
  parsed as text only, and deleted after commit/cancel (abandoned previews after 1 hour).
- Phone numbers normalised to E.164 (`+2557XXXXXXXX`); accepts `0712…`, `712…`, `255…`, `+255…`.
- Retention: `php bin/purge-old-data.php` anonymises customers older than
  `privacy.retention_days` and clears old IPs. Add to cron:
  `15 2 * * * php /var/www/ktronics-voucher/bin/purge-old-data.php`

## Backups

```
mysqldump --single-transaction ktronics | gzip > ktronics-$(date +%F).sql.gz
```
Keep `config/config.php` (the keys) with the backup but stored separately and securely.
**Test a restore** into a scratch database before going live (acceptance requirement).

## Testing done before delivery

Run against MariaDB 10.11 + PHP 8.3 with a generated 1,023-code pfSense-format roll:

- 1,023-code roll previewed and imported with correct counts and roll number (500).
- Re-uploading the same roll: 0 new codes, import blocked; mixed file: in-file and
  cross-roll duplicates skipped, malformed rows rejected with line numbers.
- Clean CSV (`voucher_code,package_id,expiry`) imported; rows for another package rejected;
  binary file and non-CSV extensions rejected.
- 20 parallel workers × 15 requests against 200 vouchers (with and without SKIP LOCKED):
  exactly 200 issued, 200 distinct vouchers, 0 left, no package mismatches.
- 5 simultaneous submits of one form → 1 acquisition.
- Sold-out package refused without issuing another package's code.
- Invalid name/phone refused with messages in Kiswahili and English; per-phone and per-IP limits enforced.
- Copy button works over plain HTTP (fallback copy) on mobile Chrome; result page 404s in another session.
- Operator cannot open the audit log or reveal codes; reveal by owner is audit-logged.

## Go-live checklist (from the specification)

1. Confirm pfSense roll durations and the portal return URL.
2. Install, create the owner, set keys, enable HTTPS (`app.force_https`).
3. Import a small test roll, issue a voucher end-to-end on a phone, log in on the captive portal with it.
4. Disable/delete the test roll, import production rolls.
5. Set `app.env` to `production`, schedule backups and the purge job, test a restore.
6. Replace `public/assets/img/brand-logo.png` with a high-resolution logo (the included
   one was taken from the specification screenshot and is small).
