<?php
/**
 * K-TRONICS Voucher Acquisition System — configuration.
 *
 * Copy this file to config/config.php and fill in the values.
 * Generate the two secret keys with:   php bin/generate-keys.php
 * Never commit config/config.php to version control.
 */
return [
    'app' => [
        'name'        => 'K-TRONICS Wi-Fi',
        'site_id'     => 'ktronics-main',          // identifier for this hotspot site
        'env'         => 'production',             // 'production' or 'development'
        'timezone'    => 'Africa/Dar_es_Salaam',
        'base_url'    => '',                       // e.g. 'https://vocha.ktronics.co.tz' (no trailing slash). Empty = auto.
        'default_lang'=> 'sw',                     // 'sw' (Kiswahili) or 'en'
        'force_https' => false,                    // true once a TLS certificate is installed
    ],

    'db' => [
        'host'     => '127.0.0.1',
        'port'     => 3306,
        'database' => 'ktronics',
        'username' => 'ktronics',
        'password' => 'change-me',
        // MySQL 8+ / MariaDB 10.6+ support SKIP LOCKED (faster under load).
        // Set to false on older servers; allocation stays safe either way.
        'skip_locked' => true,
    ],

    'security' => [
        // 32-byte keys, base64 encoded. Produce with: php bin/generate-keys.php
        // Losing encryption_key makes stored voucher codes unreadable — back it up.
        'encryption_key' => '',
        'hash_key'       => '',
        'admin_session_minutes' => 60,
    ],

    'portal' => [
        // Where "Rudi kwenye portal / Back to portal" sends the customer.
        'return_url'   => 'http://10.0.0.1:8002/index.php?zone=ktronics',
        // A ?return=… link from the captive portal is honoured only for these hosts.
        'return_hosts' => ['10.0.0.1'],
    ],

    'phone' => [
        'country_code' => '255',
    ],

    'limits' => [
        'acquisitions_per_ip_per_10min' => 5,
        'vouchers_per_phone_per_day'    => 3,
        'login_attempts_per_15min'      => 8,
        'max_upload_kb'                 => 512,
    ],

    'privacy' => [
        // Customer name/phone older than this (with no newer voucher) are anonymised
        // by: php bin/purge-old-data.php   (run it daily from cron)
        'retention_days' => 365,
    ],
];
