<?php
declare(strict_types=1);

namespace App\Core;

final class Csrf
{
    public static function token(): string
    {
        $t = Session::get('_csrf');
        if (!is_string($t) || $t === '') {
            $t = Crypto::token(32);
            Session::set('_csrf', $t);
        }
        return $t;
    }

    public static function check(): bool
    {
        $sent = $_POST['_csrf'] ?? '';
        $known = Session::get('_csrf');
        return is_string($sent) && is_string($known) && $known !== '' && hash_equals($known, $sent);
    }
}
