<?php
declare(strict_types=1);

namespace App\Core;

final class View
{
    /** Render a view inside a layout. Views receive $data keys as variables. */
    public static function render(string $view, array $data = [], string $layout = 'layouts/portal'): void
    {
        $content = self::capture($view, $data);
        echo self::capture($layout, $data + ['content' => $content]);
    }

    public static function capture(string $view, array $data = []): string
    {
        $file = BASE_PATH . '/app/Views/' . $view . '.php';
        if (!is_file($file)) {
            throw new \RuntimeException("View not found: {$view}");
        }
        extract($data, EXTR_SKIP);
        ob_start();
        require $file;
        return (string) ob_get_clean();
    }
}
