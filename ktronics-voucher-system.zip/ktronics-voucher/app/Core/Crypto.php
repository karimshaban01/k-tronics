<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/**
 * Voucher codes are encrypted at rest with libsodium secretbox and indexed by an
 * HMAC so duplicates can be detected without storing the plaintext.
 */
final class Crypto
{
    private static function key(string $name): string
    {
        $raw = base64_decode((string) Config::get('security.' . $name, ''), true);
        if ($raw === false || strlen($raw) !== 32) {
            throw new RuntimeException("security.{$name} must be a base64-encoded 32-byte key (run bin/generate-keys.php)");
        }
        return $raw;
    }

    public static function encrypt(string $plain): string
    {
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return $nonce . sodium_crypto_secretbox($plain, $nonce, self::key('encryption_key'));
    }

    public static function decrypt(string $blob): string
    {
        $nonce = substr($blob, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $cipher = substr($blob, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $plain = sodium_crypto_secretbox_open($cipher, $nonce, self::key('encryption_key'));
        if ($plain === false) {
            throw new RuntimeException('Voucher could not be decrypted — check security.encryption_key');
        }
        return $plain;
    }

    /** Binary 32-byte keyed hash of a voucher code. Codes are case-sensitive (pfSense). */
    public static function hash(string $code): string
    {
        return hash_hmac('sha256', $code, self::key('hash_key'), true);
    }

    /** "ab••••yz" style mask for lists and previews. */
    public static function mask(string $code): string
    {
        $len = mb_strlen($code);
        if ($len <= 4) {
            return str_repeat('•', $len);
        }
        return mb_substr($code, 0, 2) . '••••' . mb_substr($code, -2);
    }

    public static function token(int $bytes = 16): string
    {
        return bin2hex(random_bytes($bytes));
    }
}
