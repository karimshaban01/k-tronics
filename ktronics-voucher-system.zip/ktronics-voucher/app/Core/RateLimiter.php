<?php
declare(strict_types=1);

namespace App\Core;

/** Fixed-window rate limiter stored in MySQL (works across PHP-FPM workers). */
final class RateLimiter
{
    /**
     * Records one hit and returns true if the caller is still within the limit.
     */
    public static function hit(string $bucket, int $max, int $windowSeconds): bool
    {
        $now = time();
        $key = substr($bucket, 0, 120);
        Database::run(
            'INSERT INTO rate_limits (bucket, hits, window_start) VALUES (?, 1, ?)
             ON DUPLICATE KEY UPDATE
               hits = IF(window_start <= ? , 1, hits + 1),
               window_start = IF(window_start <= ?, VALUES(window_start), window_start)',
            [$key, $now, $now - $windowSeconds, $now - $windowSeconds]
        );
        $hits = (int) Database::value('SELECT hits FROM rate_limits WHERE bucket = ?', [$key]);
        return $hits <= $max;
    }

    public static function clear(string $bucket): void
    {
        Database::run('DELETE FROM rate_limits WHERE bucket = ?', [substr($bucket, 0, 120)]);
    }

    public static function prune(): void
    {
        Database::run('DELETE FROM rate_limits WHERE window_start < ?', [time() - 86400]);
    }
}
