<?php
declare(strict_types=1);

namespace App\Core;

final class Lang
{
    private static ?array $strings = null;
    private static string $current = 'sw';

    public static function init(): void
    {
        $lang = $_GET['lang'] ?? Session::get('lang') ?? Config::get('app.default_lang', 'sw');
        if (!in_array($lang, ['sw', 'en'], true)) {
            $lang = 'sw';
        }
        Session::set('lang', $lang);
        self::$current = $lang;
        self::$strings = require BASE_PATH . '/app/Lang/' . $lang . '.php';
    }

    public static function current(): string
    {
        return self::$current;
    }

    public static function get(string $key, array $vars = []): string
    {
        if (self::$strings === null) {
            self::$strings = require BASE_PATH . '/app/Lang/' . self::$current . '.php';
        }
        $s = self::$strings[$key] ?? $key;
        foreach ($vars as $k => $v) {
            $s = str_replace('{' . $k . '}', (string) $v, $s);
        }
        return $s;
    }
}
