<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Config;
use App\Core\Crypto;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\Lang;
use App\Core\RateLimiter;
use App\Core\Session;
use App\Core\View;
use App\Services\PhoneNormalizer;
use App\Services\VoucherAllocator;

final class PortalController
{
    public function home(): void
    {
        $this->captureReturnUrl();

        $packages = Database::all('SELECT * FROM packages WHERE active = 1 ORDER BY display_order, id');
        $stock = VoucherAllocator::stockByPackage();
        foreach ($packages as &$p) {
            $p['available'] = $stock[(int) $p['id']] ?? 0;
        }
        unset($p);

        $old = Session::get('_old', []);
        Session::forget('_old');

        View::render('portal/home', [
            'title'        => t('page_title'),
            'packages'     => $packages,
            'old'          => $old,
            'requestToken' => Crypto::token(16),
            'flash'        => Session::pullFlash(),
        ]);
    }

    public function acquire(): void
    {
        $old = [
            'full_name'  => trim((string) ($_POST['full_name'] ?? '')),
            'phone'      => trim((string) ($_POST['phone'] ?? '')),
            'package_id' => (int) ($_POST['package_id'] ?? 0),
        ];
        $fail = function (string $msg) use ($old): never {
            Session::set('_old', $old);
            Session::flash('error', $msg);
            redirect(url('/') . '#form');
        };

        if (!Csrf::check()) {
            $fail(t('err_session'));
        }

        $ipMax = (int) Config::get('limits.acquisitions_per_ip_per_10min', 5);
        if (!RateLimiter::hit('acq:ip:' . client_ip(), $ipMax, 600)) {
            $fail(t('err_rate'));
        }

        $errors = [];
        if (!preg_match('/^[\p{L}][\p{L}\p{M}\s.\'\-]{1,99}$/u', $old['full_name']) || mb_strlen($old['full_name']) < 3) {
            $errors[] = t('err_name');
        }
        $phone = PhoneNormalizer::toE164($old['phone'], (string) Config::get('phone.country_code', '255'));
        if ($phone === null) {
            $errors[] = t('err_phone');
        }
        $package = $old['package_id'] > 0
            ? Database::one('SELECT * FROM packages WHERE id = ? AND active = 1', [$old['package_id']])
            : null;
        if (!$package) {
            $errors[] = t('err_package');
        }
        if ($errors) {
            $fail(implode(' ', $errors));
        }

        $perPhone = (int) Config::get('limits.vouchers_per_phone_per_day', 3);
        if ($perPhone > 0) {
            $count = (int) Database::value(
                "SELECT COUNT(*) FROM acquisitions a JOIN customers c ON c.id = a.customer_id
                  WHERE c.phone_e164 = ? AND a.status = 'issued' AND a.created_at > (NOW() - INTERVAL 1 DAY)",
                [$phone]
            );
            if ($count >= $perPhone) {
                $fail(t('err_phone_limit', ['n' => $perPhone]));
            }
        }

        $requestToken = (string) ($_POST['request_token'] ?? '');
        if (!preg_match('/^[a-f0-9]{32}$/', $requestToken)) {
            $fail(t('err_session'));
        }

        $customerId = $this->upsertCustomer($old['full_name'], $phone);
        $returnUrl = (string) Session::get('return_url', Config::get('portal.return_url'));

        $result = (new VoucherAllocator())->issue($customerId, $package, $requestToken, $returnUrl);

        $ref = $result['public_ref'];
        if ($result['status'] === 'duplicate_request' && $ref !== null) {
            $acq = Database::one('SELECT status FROM acquisitions WHERE public_ref = ?', [$ref]);
            if (($acq['status'] ?? '') !== 'issued') {
                $result['status'] = 'out_of_stock';
            }
        }

        if ($result['status'] === 'out_of_stock') {
            $fail(t('err_out_of_stock', ['pkg' => $this->packageLabel($package)]));
        }

        $mine = Session::get('my_vouchers', []);
        $mine[] = $ref;
        Session::set('my_vouchers', array_slice(array_values(array_unique($mine)), -10));
        Session::forget('_old');

        redirect(url('/acquisitions/' . $ref . '/result'));
    }

    public function result(string $ref): void
    {
        $mine = Session::get('my_vouchers', []);
        if (!preg_match('/^[a-f0-9]{32}$/', $ref) || !in_array($ref, $mine, true)) {
            http_response_code(404);
            View::render('errors/error', ['code' => 404, 'message' => t('err_result_missing'), 'title' => t('page_title')]);
            return;
        }

        $row = Database::one(
            "SELECT a.public_ref, a.issued_at, a.portal_return_url, p.label, p.label_en, p.duration_days, p.price_tzs,
                    v.code_ciphertext, c.full_name
               FROM acquisitions a
               JOIN packages p  ON p.id = a.package_id
               JOIN vouchers v  ON v.id = a.voucher_id
               JOIN customers c ON c.id = a.customer_id
              WHERE a.public_ref = ? AND a.status = 'issued'",
            [$ref]
        );
        if (!$row) {
            http_response_code(404);
            View::render('errors/error', ['code' => 404, 'message' => t('err_result_missing'), 'title' => t('page_title')]);
            return;
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        header('Pragma: no-cache');
        header('Referrer-Policy: no-referrer');

        View::render('portal/result', [
            'title'     => t('your_voucher'),
            'code'      => \App\Core\Crypto::decrypt($row['code_ciphertext']),
            'package'   => $row,
            'firstName' => explode(' ', trim($row['full_name']))[0],
            'returnUrl' => $row['portal_return_url'] ?: (string) Config::get('portal.return_url'),
        ]);
    }

    public function privacy(): void
    {
        View::render('portal/privacy', [
            'title' => t('privacy_title'),
            'retentionDays' => (int) Config::get('privacy.retention_days', 365),
        ]);
    }

    /** Accept ?return=… from the captive portal only for allow-listed hosts (no open redirect). */
    private function captureReturnUrl(): void
    {
        $ret = $_GET['return'] ?? null;
        if (!is_string($ret) || $ret === '') {
            return;
        }
        $parts = parse_url($ret);
        $hosts = (array) Config::get('portal.return_hosts', []);
        if ($parts && in_array($parts['scheme'] ?? '', ['http', 'https'], true) && in_array($parts['host'] ?? '', $hosts, true)) {
            Session::set('return_url', mb_substr($ret, 0, 500));
        }
    }

    private function upsertCustomer(string $name, string $phone): int
    {
        $existing = Database::one('SELECT id FROM customers WHERE phone_e164 = ? ORDER BY id DESC LIMIT 1', [$phone]);
        if ($existing) {
            Database::run('UPDATE customers SET full_name = ?, updated_at = ? WHERE id = ?', [$name, now(), $existing['id']]);
            return (int) $existing['id'];
        }
        Database::run('INSERT INTO customers (full_name, phone_e164, created_at, updated_at) VALUES (?, ?, ?, ?)', [$name, $phone, now(), now()]);
        return (int) Database::pdo()->lastInsertId();
    }

    private function packageLabel(array $p): string
    {
        return Lang::current() === 'en' ? $p['label_en'] : $p['label'];
    }
}
