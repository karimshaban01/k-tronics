<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Config;
use App\Core\Crypto;
use App\Core\Database;
use App\Core\Session;
use App\Services\AuditLogger;
use App\Services\CsvImportService;

final class ImportController extends AdminBase
{
    private function dir(): string
    {
        return BASE_PATH . '/storage/imports';
    }

    public function form(): void
    {
        $this->requireAdmin();
        $this->cleanupStale();
        $this->render('admin/import', [
            'title' => 'Import voucher roll',
            'packages' => Database::all('SELECT id, label_en, price_tzs, duration_days, active FROM packages ORDER BY display_order, id'),
            'old' => Session::get('_import_old', []),
            'maxKb' => (int) Config::get('limits.max_upload_kb', 512),
        ], 'import');
    }

    public function preview(): void
    {
        $admin = $this->requireAdmin();
        $this->requirePostCsrf();

        $packageId = (int) ($_POST['package_id'] ?? 0);
        $label = trim((string) ($_POST['label'] ?? ''));
        $notes = trim((string) ($_POST['notes'] ?? ''));
        Session::set('_import_old', ['package_id' => $packageId, 'label' => $label, 'notes' => $notes]);

        $package = Database::one('SELECT * FROM packages WHERE id = ?', [$packageId]);
        $back = url('/admin/rolls/import');
        if (!$package) {
            Session::flash('error', 'Choose the package this roll belongs to.');
            redirect($back);
        }
        if (empty($_POST['confirm_mapping'])) {
            Session::flash('error', 'Confirm that the pfSense roll validity matches the selected package.');
            redirect($back);
        }

        $f = $_FILES['csv'] ?? null;
        $maxBytes = 1024 * (int) Config::get('limits.max_upload_kb', 512);
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            Session::flash('error', 'Upload failed. Choose a CSV file (max ' . (int) ($maxBytes / 1024) . ' KB).');
            redirect($back);
        }
        $original = basename((string) $f['name']);
        $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        if (!in_array($ext, ['csv', 'txt'], true) || (int) $f['size'] > $maxBytes || (int) $f['size'] === 0) {
            Session::flash('error', 'Only .csv or .txt files up to ' . (int) ($maxBytes / 1024) . ' KB are accepted.');
            redirect($back);
        }
        $token = Crypto::token(16);
        $stored = $this->dir() . '/' . $token . '.upload';
        if (!move_uploaded_file($f['tmp_name'], $stored)) {
            Session::flash('error', 'Could not store the upload. Check that storage/imports is writable.');
            redirect($back);
        }
        @chmod($stored, 0600);

        try {
            $svc = new CsvImportService();
            $parsed = $svc->parse($stored, $packageId);
            $existing = $svc->countExisting($parsed['codes']);
        } catch (\Throwable $e) {
            @unlink($stored);
            Session::flash('error', 'Could not read this file: ' . $e->getMessage());
            redirect($back);
        }

        if ($label === '') {
            $label = $package['label_en'] . ($parsed['roll_no'] !== null ? ' – pfSense roll ' . $parsed['roll_no'] : '') . ' – ' . date('Y-m-d');
        }

        Session::set('pending_import', [
            'token'      => $token,
            'sha256'     => hash_file('sha256', $stored),
            'filename'   => mb_substr($original, 0, 255),
            'package_id' => $packageId,
            'label'      => mb_substr($label, 0, 100),
            'notes'      => $notes !== '' ? mb_substr($notes, 0, 255) : null,
            'created'    => time(),
        ]);

        $this->render('admin/import_preview', [
            'title'    => 'Import preview',
            'package'  => $package,
            'parsed'   => $parsed,
            'existing' => $existing,
            'newCount' => count($parsed['codes']) - $existing,
            'label'    => $label,
            'filename' => $original,
            'samples'  => array_map(fn ($c) => Crypto::mask($c['code']), array_slice($parsed['codes'], 0, 5)),
        ], 'import');
    }

    public function commit(): void
    {
        $admin = $this->requireAdmin();
        $this->requirePostCsrf();
        $pending = Session::get('pending_import');
        Session::forget('pending_import');

        if (!$pending || ($_POST['token'] ?? '') !== $pending['token'] || time() - $pending['created'] > 3600) {
            Session::flash('error', 'This preview expired. Upload the file again.');
            redirect(url('/admin/rolls/import'));
        }
        $stored = $this->dir() . '/' . $pending['token'] . '.upload';
        if (!is_file($stored) || !hash_equals($pending['sha256'], (string) hash_file('sha256', $stored))) {
            @unlink($stored);
            Session::flash('error', 'The uploaded file is no longer available. Upload it again.');
            redirect(url('/admin/rolls/import'));
        }

        try {
            $svc = new CsvImportService();
            $parsed = $svc->parse($stored, (int) $pending['package_id']);
            $res = $svc->commit($parsed, (int) $pending['package_id'], $pending['label'], $pending['filename'], (int) $admin['id'], $pending['notes']);
        } catch (\Throwable $e) {
            Session::flash('error', 'Import failed: ' . $e->getMessage());
            redirect(url('/admin/rolls/import'));
        } finally {
            @unlink($stored);
        }

        AuditLogger::log((int) $admin['id'], 'roll_imported', 'voucher_roll', $res['roll_id'], [
            'file' => $pending['filename'], 'package_id' => (int) $pending['package_id'],
            'accepted' => $res['accepted'], 'duplicates' => $res['duplicates'], 'invalid' => $res['invalid'],
            'pfsense_roll' => $parsed['roll_no'],
        ]);
        Session::forget('_import_old');
        Session::flash('success', sprintf(
            'Imported “%s”: %d accepted, %d duplicate, %d invalid.',
            $pending['label'], $res['accepted'], $res['duplicates'], $res['invalid']
        ));
        redirect(url('/admin/stock'));
    }

    public function cancel(): void
    {
        $this->requireAdmin();
        $this->requirePostCsrf();
        $pending = Session::get('pending_import');
        if ($pending) {
            @unlink($this->dir() . '/' . $pending['token'] . '.upload');
        }
        Session::forget('pending_import');
        Session::flash('info', 'Import cancelled. Nothing was added to stock.');
        redirect(url('/admin/rolls/import'));
    }

    /** Remove abandoned preview uploads older than one hour. */
    private function cleanupStale(): void
    {
        foreach (glob($this->dir() . '/*.upload') ?: [] as $file) {
            if (filemtime($file) < time() - 3600) {
                @unlink($file);
            }
        }
    }
}
