<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Crypto;
use App\Core\Database;
use App\Core\Session;
use App\Services\AuditLogger;
use App\Services\PhoneNormalizer;
use App\Services\VoucherAllocator;

final class AdminController extends AdminBase
{
    public const LOW_STOCK = 20;

    public function dashboard(): void
    {
        $this->requireAdmin();
        $packages = $this->packagesWithStock();

        $totals = Database::one(
            "SELECT
               SUM(status = 'issued' AND issued_at >= CURDATE())                         AS today,
               SUM(status = 'issued' AND issued_at >= (CURDATE() - INTERVAL 6 DAY))     AS week,
               SUM(status = 'issued')                                                   AS total,
               SUM(status = 'out_of_stock' AND created_at >= (CURDATE() - INTERVAL 6 DAY)) AS missed_week,
               SUM(CASE WHEN status = 'issued' AND issued_at >= CURDATE() THEN amount_tzs ELSE 0 END) AS value_today
             FROM acquisitions"
        );
        $recent = Database::all(
            "SELECT a.id, a.created_at, a.status, a.amount_tzs, c.full_name, c.phone_e164, p.label_en, v.code_hint
               FROM acquisitions a
               JOIN customers c ON c.id = a.customer_id
               JOIN packages p ON p.id = a.package_id
               LEFT JOIN vouchers v ON v.id = a.voucher_id
              ORDER BY a.id DESC LIMIT 10"
        );

        $this->render('admin/dashboard', compact('packages', 'totals', 'recent') + ['title' => 'Dashboard'], 'dashboard');
    }

    public function stock(): void
    {
        $this->requireAdmin();
        $packages = $this->packagesWithStock();
        $rolls = Database::all(
            "SELECT r.*, p.label_en AS package_label, p.price_tzs, a.name AS imported_by_name,
                    SUM(v.status = 'available') AS available,
                    SUM(v.status = 'issued')    AS issued,
                    SUM(v.status = 'void')      AS voided
               FROM voucher_rolls r
               JOIN packages p ON p.id = r.package_id
               JOIN admins a ON a.id = r.imported_by
               LEFT JOIN vouchers v ON v.roll_id = r.id
              GROUP BY r.id
              ORDER BY r.id DESC"
        );
        $this->render('admin/stock', ['title' => 'Stock', 'packages' => $packages, 'rolls' => $rolls], 'stock');
    }

    public function rollStatus(string $id): void
    {
        $this->requireAdmin('owner');
        $this->requirePostCsrf();
        $status = ($_POST['status'] ?? '') === 'active' ? 'active' : 'disabled';
        $roll = Database::one('SELECT id, label FROM voucher_rolls WHERE id = ?', [(int) $id]);
        if ($roll) {
            Database::run('UPDATE voucher_rolls SET status = ? WHERE id = ?', [$status, $roll['id']]);
            AuditLogger::log((int) $this->admin['id'], 'roll_' . $status, 'voucher_roll', (int) $roll['id'], ['label' => $roll['label']]);
            Session::flash('success', "Roll “{$roll['label']}” is now {$status}.");
        }
        redirect(url('/admin/stock'));
    }

    public function acquisitions(): void
    {
        $this->requireAdmin();
        $q = trim((string) ($_GET['q'] ?? ''));
        $pkg = (int) ($_GET['package_id'] ?? 0);
        $status = (string) ($_GET['status'] ?? '');
        $from = (string) ($_GET['from'] ?? '');
        $to = (string) ($_GET['to'] ?? '');
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $per = 50;

        $where = ['1=1'];
        $params = [];
        if ($q !== '') {
            $phone = PhoneNormalizer::toE164($q);
            if ($phone !== null) {
                $where[] = 'c.phone_e164 = ?';
                $params[] = $phone;
            } else {
                $where[] = '(c.full_name LIKE ? OR c.phone_e164 LIKE ?)';
                $like = '%' . addcslashes($q, '%_\\') . '%';
                array_push($params, $like, $like);
            }
        }
        if ($pkg > 0) {
            $where[] = 'a.package_id = ?';
            $params[] = $pkg;
        }
        if (in_array($status, ['issued', 'out_of_stock', 'pending', 'failed'], true)) {
            $where[] = 'a.status = ?';
            $params[] = $status;
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
            $where[] = 'a.created_at >= ?';
            $params[] = $from . ' 00:00:00';
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
            $where[] = 'a.created_at <= ?';
            $params[] = $to . ' 23:59:59';
        }
        $sqlWhere = implode(' AND ', $where);
        $base = "FROM acquisitions a
                   JOIN customers c ON c.id = a.customer_id
                   JOIN packages p ON p.id = a.package_id
                   LEFT JOIN vouchers v ON v.id = a.voucher_id
                  WHERE {$sqlWhere}";

        $total = (int) Database::value("SELECT COUNT(*) {$base}", $params);
        $rows = Database::all(
            "SELECT a.id, a.created_at, a.issued_at, a.status, a.amount_tzs, a.client_ip,
                    c.full_name, c.phone_e164, p.label_en, v.code_hint, v.id AS voucher_id
               {$base}
              ORDER BY a.id DESC
              LIMIT {$per} OFFSET " . (($page - 1) * $per),
            $params
        );

        $this->render('admin/acquisitions', [
            'title' => 'Issued vouchers',
            'rows' => $rows, 'total' => $total, 'page' => $page, 'pages' => max(1, (int) ceil($total / $per)),
            'filters' => compact('q', 'pkg', 'status', 'from', 'to'),
            'packages' => Database::all('SELECT id, label_en FROM packages ORDER BY display_order, id'),
            'canReveal' => $this->isOwner(),
        ], 'acquisitions');
    }

    /** Owner-only, audited display of one issued voucher (e.g. a customer lost the code). */
    public function reveal(string $id): void
    {
        $this->requireAdmin('owner');
        $this->requirePostCsrf();
        $row = Database::one(
            "SELECT a.id, a.created_at, c.full_name, c.phone_e164, p.label_en, v.code_ciphertext, v.id AS voucher_id
               FROM acquisitions a
               JOIN customers c ON c.id = a.customer_id
               JOIN packages p ON p.id = a.package_id
               JOIN vouchers v ON v.id = a.voucher_id
              WHERE a.id = ? AND a.status = 'issued'",
            [(int) $id]
        );
        if (!$row) {
            Session::flash('error', 'No issued voucher for that record.');
            redirect(url('/admin/acquisitions'));
        }
        AuditLogger::log((int) $this->admin['id'], 'voucher_revealed', 'acquisition', (int) $row['id'], ['voucher_id' => (int) $row['voucher_id']]);
        $this->render('admin/reveal', [
            'title' => 'Voucher code',
            'row' => $row,
            'code' => Crypto::decrypt($row['code_ciphertext']),
        ], 'acquisitions');
    }

    public function packages(): void
    {
        $this->requireAdmin();
        $this->render('admin/packages', [
            'title' => 'Packages',
            'packages' => $this->packagesWithStock(true),
            'canEdit' => $this->isOwner(),
        ], 'packages');
    }

    public function savePackage(): void
    {
        $this->requireAdmin('owner');
        $this->requirePostCsrf();
        $id = (int) ($_POST['id'] ?? 0);
        $data = [
            'label'         => trim((string) ($_POST['label'] ?? '')),
            'label_en'      => trim((string) ($_POST['label_en'] ?? '')),
            'price_tzs'     => (int) ($_POST['price_tzs'] ?? -1),
            'duration_days' => (int) ($_POST['duration_days'] ?? 0),
            'display_order' => (int) ($_POST['display_order'] ?? 0),
            'active'        => isset($_POST['active']) ? 1 : 0,
        ];
        $errors = [];
        if ($data['label'] === '' || mb_strlen($data['label']) > 60) $errors[] = 'Kiswahili label is required (max 60).';
        if ($data['label_en'] === '' || mb_strlen($data['label_en']) > 60) $errors[] = 'English label is required (max 60).';
        if ($data['price_tzs'] < 0 || $data['price_tzs'] > 10_000_000) $errors[] = 'Price must be 0–10,000,000 TZS.';
        if ($data['duration_days'] < 1 || $data['duration_days'] > 366) $errors[] = 'Duration must be 1–366 days.';
        if ($errors) {
            Session::flash('error', implode(' ', $errors));
            redirect(url('/admin/packages'));
        }

        if ($id > 0) {
            $before = Database::one('SELECT * FROM packages WHERE id = ?', [$id]);
            if (!$before) {
                redirect(url('/admin/packages'));
            }
            Database::run(
                'UPDATE packages SET label=?, label_en=?, price_tzs=?, duration_days=?, display_order=?, active=?, updated_at=? WHERE id=?',
                [$data['label'], $data['label_en'], $data['price_tzs'], $data['duration_days'], $data['display_order'], $data['active'], now(), $id]
            );
            AuditLogger::log((int) $this->admin['id'], 'package_updated', 'package', $id, [
                'before' => array_intersect_key($before, $data), 'after' => $data,
            ]);
            $msg = "Package “{$data['label_en']}” saved.";
            if ((int) $before['duration_days'] !== $data['duration_days']) {
                $msg .= ' Duration changed: make sure the vouchers imported for this package really have the new validity in pfSense.';
            }
            Session::flash('success', $msg);
        } else {
            Database::run(
                'INSERT INTO packages (label, label_en, price_tzs, duration_days, display_order, active, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)',
                [$data['label'], $data['label_en'], $data['price_tzs'], $data['duration_days'], $data['display_order'], $data['active'], now(), now()]
            );
            $newId = (int) Database::pdo()->lastInsertId();
            AuditLogger::log((int) $this->admin['id'], 'package_created', 'package', $newId, $data);
            Session::flash('success', "Package “{$data['label_en']}” created.");
        }
        redirect(url('/admin/packages'));
    }

    public function audit(): void
    {
        $this->requireAdmin('owner');
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $per = 100;
        $total = (int) Database::value('SELECT COUNT(*) FROM audit_logs');
        $rows = Database::all(
            'SELECT l.*, a.name AS admin_name FROM audit_logs l LEFT JOIN admins a ON a.id = l.admin_id
              ORDER BY l.id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per)
        );
        $this->render('admin/audit', [
            'title' => 'Audit log', 'rows' => $rows, 'page' => $page, 'pages' => max(1, (int) ceil($total / $per)),
        ], 'audit');
    }

    public function admins(): void
    {
        $this->requireAdmin('owner');
        $this->render('admin/admins', [
            'title' => 'Admin users',
            'admins' => Database::all('SELECT id, name, email, role, active, created_at, last_login_at FROM admins ORDER BY id'),
        ], 'admins');
    }

    public function saveAdmin(): void
    {
        $this->requireAdmin('owner');
        $this->requirePostCsrf();
        $name = trim((string) ($_POST['name'] ?? ''));
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $role = ($_POST['role'] ?? '') === 'owner' ? 'owner' : 'operator';
        $password = (string) ($_POST['password'] ?? '');
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 10) {
            Session::flash('error', 'Name, a valid email and a password of at least 10 characters are required.');
            redirect(url('/admin/admins'));
        }
        if (Database::value('SELECT id FROM admins WHERE email = ?', [$email])) {
            Session::flash('error', 'An admin with that email already exists.');
            redirect(url('/admin/admins'));
        }
        Database::run(
            'INSERT INTO admins (name, email, password_hash, role, active, created_at) VALUES (?, ?, ?, ?, 1, ?)',
            [$name, $email, password_hash($password, PASSWORD_DEFAULT), $role, now()]
        );
        AuditLogger::log((int) $this->admin['id'], 'admin_created', 'admin', (int) Database::pdo()->lastInsertId(), ['email' => $email, 'role' => $role]);
        Session::flash('success', "Admin {$email} created. Ask them to change the password after first sign-in.");
        redirect(url('/admin/admins'));
    }

    public function toggleAdmin(string $id): void
    {
        $this->requireAdmin('owner');
        $this->requirePostCsrf();
        $id = (int) $id;
        if ($id === (int) $this->admin['id']) {
            Session::flash('error', 'You cannot disable your own account.');
            redirect(url('/admin/admins'));
        }
        $target = Database::one('SELECT id, email, active FROM admins WHERE id = ?', [$id]);
        if ($target) {
            $new = (int) $target['active'] ? 0 : 1;
            Database::run('UPDATE admins SET active = ? WHERE id = ?', [$new, $id]);
            AuditLogger::log((int) $this->admin['id'], $new ? 'admin_enabled' : 'admin_disabled', 'admin', $id, ['email' => $target['email']]);
            Session::flash('success', $target['email'] . ($new ? ' enabled.' : ' disabled.'));
        }
        redirect(url('/admin/admins'));
    }

    public function account(): void
    {
        $this->requireAdmin();
        $this->render('admin/account', ['title' => 'My account'], 'account');
    }

    public function changePassword(): void
    {
        $admin = $this->requireAdmin();
        $this->requirePostCsrf();
        $current = (string) ($_POST['current_password'] ?? '');
        $new = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['confirm_password'] ?? '');
        $hash = (string) Database::value('SELECT password_hash FROM admins WHERE id = ?', [$admin['id']]);
        if (!password_verify($current, $hash)) {
            Session::flash('error', 'Current password is incorrect.');
        } elseif (strlen($new) < 10 || $new !== $confirm) {
            Session::flash('error', 'New password must be at least 10 characters and match the confirmation.');
        } else {
            Database::run('UPDATE admins SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $admin['id']]);
            AuditLogger::log((int) $admin['id'], 'password_changed', 'admin', (int) $admin['id']);
            Session::regenerate();
            Session::flash('success', 'Password changed.');
        }
        redirect(url('/admin/account'));
    }

    private function packagesWithStock(bool $includeInactive = false): array
    {
        $packages = Database::all(
            'SELECT p.*,
                    (SELECT COUNT(*) FROM acquisitions a WHERE a.package_id = p.id AND a.status = \'issued\' AND a.issued_at >= CURDATE()) AS issued_today,
                    (SELECT COUNT(*) FROM vouchers v WHERE v.package_id = p.id AND v.status = \'issued\') AS issued_total
               FROM packages p ' . ($includeInactive ? '' : 'WHERE p.active = 1 ') . 'ORDER BY p.display_order, p.id'
        );
        $stock = VoucherAllocator::stockByPackage();
        foreach ($packages as &$p) {
            $p['available'] = $stock[(int) $p['id']] ?? 0;
        }
        return $packages;
    }
}
