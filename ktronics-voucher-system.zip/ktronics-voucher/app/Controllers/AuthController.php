<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Config;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\RateLimiter;
use App\Core\Session;
use App\Core\View;
use App\Services\AuditLogger;

final class AuthController
{
    public function showLogin(): void
    {
        if (Session::get('admin_id')) {
            redirect(url('/admin'));
        }
        View::render('admin/login', [
            'title' => 'Admin sign in',
            'flash' => Session::pullFlash(),
            'email' => Session::get('_login_email', ''),
        ], 'layouts/admin_bare');
    }

    public function login(): void
    {
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');
        Session::set('_login_email', $email);

        if (!Csrf::check()) {
            Session::flash('error', 'The form expired. Please try again.');
            redirect(url('/admin/login'));
        }

        $max = (int) Config::get('limits.login_attempts_per_15min', 8);
        $ipOk = RateLimiter::hit('login:ip:' . client_ip(), $max * 3, 900);
        $userOk = RateLimiter::hit('login:user:' . hash('sha256', $email), $max, 900);
        if (!$ipOk || !$userOk) {
            AuditLogger::log(null, 'login_throttled', 'admin', null, ['email' => $email]);
            Session::flash('error', 'Too many sign-in attempts. Wait 15 minutes and try again.');
            redirect(url('/admin/login'));
        }

        $admin = Database::one('SELECT id, password_hash, active FROM admins WHERE email = ?', [$email]);
        // Verify against a dummy hash when the user does not exist, to keep timing similar.
        $hash = $admin['password_hash'] ?? '$2y$10$abcdefghijklmnopqrstuuJ1qSMt7j4k0QdGqmh8C1Yp8nYxVxqKe';
        $ok = password_verify($password, $hash) && $admin && (int) $admin['active'] === 1;

        if (!$ok) {
            AuditLogger::log($admin ? (int) $admin['id'] : null, 'login_failed', 'admin', $admin ? (int) $admin['id'] : null, ['email' => $email]);
            Session::flash('error', 'Email or password is incorrect.');
            redirect(url('/admin/login'));
        }

        if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
            Database::run('UPDATE admins SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), $admin['id']]);
        }

        Session::regenerate();
        Session::forget('_login_email');
        Session::set('_csrf', bin2hex(random_bytes(32)));
        Session::set('admin_id', (int) $admin['id']);
        Session::set('admin_seen', time());
        RateLimiter::clear('login:user:' . hash('sha256', $email));
        Database::run('UPDATE admins SET last_login_at = ? WHERE id = ?', [now(), $admin['id']]);
        AuditLogger::log((int) $admin['id'], 'login', 'admin', (int) $admin['id']);

        redirect(url('/admin'));
    }

    public function logout(): void
    {
        if (Csrf::check()) {
            $id = (int) Session::get('admin_id', 0);
            if ($id) {
                AuditLogger::log($id, 'logout', 'admin', $id);
            }
            Session::forget('admin_id');
            Session::regenerate();
        }
        redirect(url('/admin/login'));
    }
}
