<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Config;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\Session;
use App\Core\View;

abstract class AdminBase
{
    protected ?array $admin = null;

    /** Ensure an active admin is logged in; optionally require the owner role. */
    protected function requireAdmin(?string $role = null): array
    {
        $id = (int) Session::get('admin_id', 0);
        $last = (int) Session::get('admin_seen', 0);
        $timeout = 60 * (int) Config::get('security.admin_session_minutes', 60);

        if ($id === 0 || ($last > 0 && time() - $last > $timeout)) {
            Session::forget('admin_id');
            if ($id !== 0) {
                Session::flash('info', 'Your session timed out. Please sign in again.');
            }
            redirect(url('/admin/login'));
        }
        $admin = Database::one('SELECT id, name, email, role, active FROM admins WHERE id = ?', [$id]);
        if (!$admin || !(int) $admin['active']) {
            Session::forget('admin_id');
            redirect(url('/admin/login'));
        }
        if ($role !== null && $admin['role'] !== $role) {
            http_response_code(403);
            $this->render('admin/forbidden', ['title' => 'Not allowed'], '');
            exit;
        }
        Session::set('admin_seen', time());
        $this->admin = $admin;
        return $admin;
    }

    protected function requirePostCsrf(): void
    {
        if (!Csrf::check()) {
            Session::flash('error', 'The form expired. Please try again.');
            redirect($_SERVER['HTTP_REFERER'] ?? url('/admin'));
        }
    }

    protected function render(string $view, array $data, string $nav): void
    {
        header('Cache-Control: no-store, private');
        View::render($view, $data + [
            'admin' => $this->admin,
            'nav'   => $nav,
            'flash' => Session::pullFlash(),
        ], 'layouts/admin');
    }

    protected function isOwner(): bool
    {
        return ($this->admin['role'] ?? '') === 'owner';
    }
}
