<?php
declare(strict_types=1);

use App\Core\Config;
use App\Core\Csrf;
use App\Core\Lang;

/** Escape for HTML output. */
function e(mixed $value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Build an application URL from a path such as '/admin/stock'. */
function url(string $path = '/', array $query = []): string
{
    $base = rtrim((string) Config::get('app.base_url', ''), '/');
    if ($base === '') {
        $script = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
        $base = rtrim($script === '/' ? '' : $script, '/');
    }
    $q = $query ? ('?' . http_build_query($query)) : '';
    return $base . '/' . ltrim($path, '/') . $q;
}

function asset(string $path): string
{
    $file = BASE_PATH . '/public/assets/' . ltrim($path, '/');
    $v = is_file($file) ? (string) filemtime($file) : '1';
    return url('/assets/' . ltrim($path, '/'), ['v' => $v]);
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(Csrf::token()) . '">';
}

/** Translate a public-portal string. */
function t(string $key, array $vars = []): string
{
    return Lang::get($key, $vars);
}

function tzs(int $amount): string
{
    return 'TZS ' . number_format($amount);
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

function redirect(string $to, int $status = 303): never
{
    header('Location: ' . $to, true, $status);
    exit;
}

function client_ip(): string
{
    // Behind a reverse proxy, configure the web server to set REMOTE_ADDR correctly
    // instead of trusting X-Forwarded-For from the client.
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443');
}

function duration_label(int $days, string $lang): string
{
    if ($lang === 'en') {
        return $days === 1 ? '1 day' : $days . ' days';
    }
    return 'Siku ' . $days;
}
