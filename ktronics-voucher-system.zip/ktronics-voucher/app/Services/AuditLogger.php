<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

final class AuditLogger
{
    /** Never pass plaintext voucher codes in $metadata. */
    public static function log(?int $adminId, string $action, ?string $targetType = null, ?int $targetId = null, array $metadata = []): void
    {
        Database::run(
            'INSERT INTO audit_logs (admin_id, action, target_type, target_id, metadata_json, ip, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            [
                $adminId,
                $action,
                $targetType,
                $targetId,
                $metadata ? json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
                client_ip(),
                now(),
            ]
        );
    }
}
