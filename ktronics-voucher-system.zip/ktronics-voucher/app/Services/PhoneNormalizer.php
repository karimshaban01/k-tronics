<?php
declare(strict_types=1);

namespace App\Services;

/**
 * Normalises Tanzanian mobile numbers to E.164 (+255XXXXXXXXX).
 * Accepts 0712 345 678, 712345678, 255712345678, +255 712-345-678, 00255712345678.
 */
final class PhoneNormalizer
{
    public static function toE164(string $input, string $countryCode = '255'): ?string
    {
        $digits = preg_replace('/\D+/', '', $input) ?? '';
        if ($digits === '') {
            return null;
        }
        if (str_starts_with($digits, '00' . $countryCode)) {
            $digits = substr($digits, 2 + strlen($countryCode));
        } elseif (str_starts_with($digits, $countryCode) && strlen($digits) === strlen($countryCode) + 9) {
            $digits = substr($digits, strlen($countryCode));
        } elseif (str_starts_with($digits, '0') && strlen($digits) === 10) {
            $digits = substr($digits, 1);
        }
        // Tanzanian mobile numbers: 9 national digits starting with 6 or 7.
        if (!preg_match('/^[67]\d{8}$/', $digits)) {
            return null;
        }
        return '+' . $countryCode . $digits;
    }

    /** +255712345678 → 0712 345 678 for display. */
    public static function display(string $e164): string
    {
        if (preg_match('/^\+255(\d{3})(\d{3})(\d{3})$/', $e164, $m)) {
            return '0' . $m[1] . ' ' . $m[2] . ' ' . $m[3];
        }
        return $e164;
    }
}
