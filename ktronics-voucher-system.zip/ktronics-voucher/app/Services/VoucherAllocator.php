<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Config;
use App\Core\Crypto;
use App\Core\Database;
use PDOException;

/**
 * Issues exactly one stored voucher per acquisition, from the requested package only.
 *
 * Safety:
 *  - The whole issuance runs in one InnoDB transaction.
 *  - The candidate voucher row is locked with SELECT … FOR UPDATE (SKIP LOCKED when available).
 *  - The status change is guarded (WHERE status = 'available') and its row count checked.
 *  - acquisitions.voucher_id is UNIQUE, so the database itself refuses a double issue.
 *  - request_token is UNIQUE, so a double-tap or browser resubmit returns the same voucher.
 */
final class VoucherAllocator
{
    /**
     * @return array{status:string, public_ref:?string, acquisition_id:?int}
     *         status: issued | out_of_stock | duplicate_request
     */
    public function issue(int $customerId, array $package, string $requestToken, ?string $returnUrl): array
    {
        $existing = Database::one('SELECT id, public_ref, status FROM acquisitions WHERE request_token = ?', [$requestToken]);
        if ($existing) {
            return ['status' => 'duplicate_request', 'public_ref' => $existing['public_ref'], 'acquisition_id' => (int) $existing['id']];
        }

        $attempts = 0;
        while (true) {
            $attempts++;
            try {
                return $this->attempt($customerId, $package, $requestToken, $returnUrl);
            } catch (PDOException $e) {
                $code = (int) ($e->errorInfo[1] ?? 0);
                if ($code === 1062) {
                    // Same request_token inserted by a parallel resubmit: return that one.
                    $row = Database::one('SELECT id, public_ref FROM acquisitions WHERE request_token = ?', [$requestToken]);
                    if ($row) {
                        return ['status' => 'duplicate_request', 'public_ref' => $row['public_ref'], 'acquisition_id' => (int) $row['id']];
                    }
                }
                // 1213 deadlock, 1205 lock wait timeout: safe to retry the whole transaction.
                if (in_array($code, [1213, 1205], true) && $attempts < 4) {
                    usleep(random_int(20_000, 120_000));
                    continue;
                }
                throw $e;
            }
        }
    }

    private function attempt(int $customerId, array $package, string $requestToken, ?string $returnUrl): array
    {
        $pdo = Database::pdo();
        $packageId = (int) $package['id'];
        $publicRef = Crypto::token(16);

        // Active rolls for this package (read without locks; a roll disabled a moment
        // later just means this one last voucher was already in flight).
        $rollIds = array_map('intval', array_column(
            Database::all('SELECT id FROM voucher_rolls WHERE package_id = ? AND status = \'active\'', [$packageId]),
            'id'
        ));

        $pdo->beginTransaction();
        try {
            Database::run(
                'INSERT INTO acquisitions (public_ref, request_token, customer_id, package_id, amount_tzs, status, client_ip, created_at, portal_return_url)
                 VALUES (?, ?, ?, ?, ?, \'pending\', ?, ?, ?)',
                [$publicRef, $requestToken, $customerId, $packageId, (int) $package['price_tzs'], client_ip(), now(), $returnUrl]
            );
            $acqId = (int) $pdo->lastInsertId();

            $voucherId = null;
            if ($rollIds) {
                $in = implode(',', $rollIds); // integers only
                $lock = Config::get('db.skip_locked', true) ? 'FOR UPDATE SKIP LOCKED' : 'FOR UPDATE';
                for ($i = 0; $i < 5 && $voucherId === null; $i++) {
                    $candidate = Database::value(
                        "SELECT id FROM vouchers
                          WHERE package_id = ? AND status = 'available' AND roll_id IN ($in)
                            AND (expires_at IS NULL OR expires_at > NOW())
                          ORDER BY id
                          LIMIT 1 {$lock}",
                        [$packageId]
                    );
                    if ($candidate === null) {
                        break;
                    }
                    $upd = Database::run(
                        'UPDATE vouchers SET status = \'issued\', issued_to_acquisition_id = ?, issued_at = ?
                          WHERE id = ? AND status = \'available\' AND package_id = ?',
                        [$acqId, now(), (int) $candidate, $packageId]
                    );
                    if ($upd->rowCount() === 1) {
                        $voucherId = (int) $candidate;
                    }
                }
            }

            if ($voucherId === null) {
                Database::run('UPDATE acquisitions SET status = \'out_of_stock\' WHERE id = ?', [$acqId]);
                $pdo->commit();
                return ['status' => 'out_of_stock', 'public_ref' => null, 'acquisition_id' => $acqId];
            }

            Database::run(
                'UPDATE acquisitions SET status = \'issued\', voucher_id = ?, issued_at = ? WHERE id = ?',
                [$voucherId, now(), $acqId]
            );
            $pdo->commit();
            return ['status' => 'issued', 'public_ref' => $publicRef, 'acquisition_id' => $acqId];
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    /** Available stock per package, counting only active, unexpired rolls. */
    public static function stockByPackage(): array
    {
        $rows = Database::all(
            "SELECT v.package_id, COUNT(*) AS available
               FROM vouchers v JOIN voucher_rolls r ON r.id = v.roll_id
              WHERE v.status = 'available' AND r.status = 'active'
                AND (v.expires_at IS NULL OR v.expires_at > NOW())
              GROUP BY v.package_id"
        );
        $out = [];
        foreach ($rows as $r) {
            $out[(int) $r['package_id']] = (int) $r['available'];
        }
        return $out;
    }
}
