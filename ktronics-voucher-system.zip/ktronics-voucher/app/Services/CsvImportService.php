<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Crypto;
use App\Core\Database;
use RuntimeException;

/**
 * Parses voucher CSV files in two formats:
 *
 *  1. pfSense voucher roll export — "#" metadata lines (roll number, bit counts,
 *     character set) followed by one voucher per line, usually in double quotes.
 *  2. Clean CSV with a header row: voucher_code[,package_id][,expiry]
 *
 * Uploaded content is only ever read as text; nothing in it is executed or evaluated.
 */
final class CsvImportService
{
    public const MAX_ROWS = 20000;
    private const DEFAULT_CODE_RE = '/^[A-Za-z0-9._\-]{4,64}$/';

    /**
     * @return array{
     *   format:string, meta:array<string,string>, roll_no:?int, charset:?string,
     *   rows:int, codes:array<int,array{code:string,line:int,expires_at:?string}>,
     *   invalid:array<int,array{line:int,reason:string,sample:string}>,
     *   dup_in_file:int
     * }
     */
    public function parse(string $path, int $packageId): array
    {
        $raw = file_get_contents($path);
        if ($raw === false) {
            throw new RuntimeException('Could not read the uploaded file.');
        }
        if (str_contains($raw, "\0")) {
            throw new RuntimeException('The file looks binary, not a CSV text file.');
        }
        $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw) ?? $raw;              // strip UTF-8 BOM
        if (!mb_check_encoding($raw, 'UTF-8')) {
            $raw = mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
        }
        $lines = preg_split('/\r\n|\n|\r/', $raw) ?: [];
        if (count($lines) > self::MAX_ROWS) {
            throw new RuntimeException('File has more than ' . self::MAX_ROWS . ' lines.');
        }

        $result = [
            'format' => 'pfsense', 'meta' => [], 'roll_no' => null, 'charset' => null,
            'rows' => 0, 'codes' => [], 'invalid' => [], 'dup_in_file' => 0,
        ];

        // Detect a clean CSV header on the first non-empty, non-comment line.
        $header = null;
        foreach ($lines as $idx => $line) {
            $trim = trim($line);
            if ($trim === '' || str_starts_with($trim, '#')) {
                continue;
            }
            $cols = array_map(fn ($c) => strtolower(trim((string) $c)), str_getcsv($trim));
            if (in_array('voucher_code', $cols, true) || in_array('code', $cols, true)) {
                $header = ['line' => $idx, 'cols' => $cols];
                $result['format'] = 'csv';
            }
            break;
        }

        $seen = [];
        $seenCode = false;

        foreach ($lines as $idx => $line) {
            $lineNo = $idx + 1;
            $trim = trim($line);
            if ($trim === '') {
                continue;
            }
            if ($header !== null && $idx === $header['line']) {
                continue;
            }

            // Metadata / comment rows.
            if (str_starts_with($trim, '#')) {
                $this->readMeta(ltrim($trim, "# \t"), $result);
                continue;
            }

            $result['rows']++;
            $expires = null;

            if ($header !== null) {
                $fields = str_getcsv($trim);
                $map = [];
                foreach ($header['cols'] as $i => $name) {
                    $map[$name] = isset($fields[$i]) ? trim((string) $fields[$i]) : '';
                }
                $code = $map['voucher_code'] ?? $map['code'] ?? '';
                if (isset($map['package_id']) && $map['package_id'] !== '' && (int) $map['package_id'] !== $packageId) {
                    $result['invalid'][] = ['line' => $lineNo, 'reason' => 'package_id ' . $map['package_id'] . ' does not match the selected package', 'sample' => Crypto::mask($code)];
                    continue;
                }
                $exp = $map['expiry'] ?? $map['expires_at'] ?? '';
                if ($exp !== '') {
                    $ts = strtotime($exp);
                    if ($ts === false) {
                        $result['invalid'][] = ['line' => $lineNo, 'reason' => 'unreadable expiry date', 'sample' => Crypto::mask($code)];
                        continue;
                    }
                    $expires = date('Y-m-d H:i:s', $ts);
                }
            } else {
                // Single-column roll: first field, quotes and spaces removed.
                $fields = str_getcsv($trim);
                $code = trim((string) ($fields[0] ?? ''), " \t\"'");
                if (count(array_filter($fields, fn ($f) => trim((string) $f) !== '')) > 1 && !$seenCode) {
                    // A multi-field line before any code is header text, not a voucher.
                    $this->readMeta($trim, $result);
                    $result['rows']--;
                    continue;
                }
            }

            $reason = $this->validate($code, $result['charset']);
            if ($reason !== null) {
                if (!$seenCode && $header === null && preg_match('/\s/', $code)) {
                    // Free-text header line before the first voucher (no "#").
                    $this->readMeta($trim, $result);
                    $result['rows']--;
                    continue;
                }
                $result['invalid'][] = ['line' => $lineNo, 'reason' => $reason, 'sample' => Crypto::mask($code)];
                continue;
            }

            $seenCode = true;
            if (isset($seen[$code])) {
                $result['dup_in_file']++;
                continue;
            }
            $seen[$code] = true;
            $result['codes'][] = ['code' => $code, 'line' => $lineNo, 'expires_at' => $expires];
        }

        return $result;
    }

    private function readMeta(string $text, array &$result): void
    {
        $text = trim($text, " \t\"'");
        if ($text === '') {
            return;
        }
        if (preg_match('/for\s+Roll\s+(\d+)/i', $text, $m)) {
            $result['roll_no'] = (int) $m[1];
        }
        if (preg_match('/^(Character\s+Set(?:\s+used)?|charset)\s*[:=]?\s*(\S+)$/i', $text, $m)) {
            $result['charset'] = $m[2];
        }
        if (count($result['meta']) < 20) {
            $result['meta'][] = mb_substr($text, 0, 120);
        }
    }

    private function validate(string $code, ?string $charset): ?string
    {
        if ($code === '') {
            return 'empty value';
        }
        if (!preg_match(self::DEFAULT_CODE_RE, $code)) {
            return 'contains invalid characters or wrong length';
        }
        if ($charset !== null && $charset !== '') {
            $allowed = array_flip(str_split($charset));
            foreach (str_split($code) as $ch) {
                if (!isset($allowed[$ch])) {
                    return 'character outside the roll\'s declared character set';
                }
            }
        }
        return null;
    }

    /** Count codes from the parse result that already exist in the database. */
    public function countExisting(array $codes): int
    {
        $existing = 0;
        foreach (array_chunk($codes, 500) as $chunk) {
            $hashes = array_map(fn ($c) => Crypto::hash($c['code']), $chunk);
            $in = implode(',', array_fill(0, count($hashes), '?'));
            $existing += (int) Database::value("SELECT COUNT(*) FROM vouchers WHERE code_hash IN ($in)", $hashes);
        }
        return $existing;
    }

    /**
     * Insert parsed codes as a new roll. Returns the roll id and counts.
     *
     * @return array{roll_id:int, accepted:int, duplicates:int, invalid:int}
     */
    public function commit(array $parsed, int $packageId, string $label, string $filename, int $adminId, ?string $notes = null): array
    {
        $pdo = Database::pdo();
        $pdo->beginTransaction();
        try {
            Database::run(
                'INSERT INTO voucher_rolls (label, source_filename, package_id, pfsense_roll_no, imported_by, imported_at, status, notes)
                 VALUES (?, ?, ?, ?, ?, ?, \'active\', ?)',
                [$label, $filename, $packageId, $parsed['roll_no'], $adminId, now(), $notes]
            );
            $rollId = (int) $pdo->lastInsertId();

            $accepted = 0;
            $created = now();
            foreach (array_chunk($parsed['codes'], 250) as $chunk) {
                $placeholders = [];
                $params = [];
                foreach ($chunk as $c) {
                    $placeholders[] = '(?, ?, ?, ?, ?, \'available\', ?, ?)';
                    array_push(
                        $params,
                        $rollId,
                        $packageId,
                        Crypto::encrypt($c['code']),
                        Crypto::hash($c['code']),
                        Crypto::mask($c['code']),
                        $c['expires_at'],
                        $created
                    );
                }
                // INSERT IGNORE skips rows whose code_hash already exists (duplicates across rolls).
                $stmt = Database::run(
                    'INSERT IGNORE INTO vouchers (roll_id, package_id, code_ciphertext, code_hash, code_hint, status, expires_at, created_at) VALUES '
                    . implode(',', $placeholders),
                    $params
                );
                $accepted += $stmt->rowCount();
            }

            $duplicates = $parsed['dup_in_file'] + (count($parsed['codes']) - $accepted);
            $invalid = count($parsed['invalid']);

            if ($accepted === 0) {
                throw new RuntimeException('No new voucher codes in this file — every valid code is already in stock or was issued before.');
            }

            Database::run(
                'UPDATE voucher_rolls SET total_count = ?, duplicate_count = ?, invalid_count = ? WHERE id = ?',
                [$accepted, $duplicates, $invalid, $rollId]
            );
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        return ['roll_id' => $rollId, 'accepted' => $accepted, 'duplicates' => $duplicates, 'invalid' => $invalid];
    }
}
