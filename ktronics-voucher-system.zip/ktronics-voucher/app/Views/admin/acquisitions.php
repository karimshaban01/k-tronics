<?php
use App\Services\PhoneNormalizer;
$qs = function (array $over) use ($filters) {
    $base = ['q' => $filters['q'], 'package_id' => $filters['pkg'] ?: null, 'status' => $filters['status'] ?: null, 'from' => $filters['from'] ?: null, 'to' => $filters['to'] ?: null];
    return url('/admin/acquisitions', array_filter($over + $base, fn ($v) => $v !== null && $v !== ''));
};
?>
<h1>Issued vouchers</h1>

<form class="panel" method="get" action="<?= e(url('/admin/acquisitions')) ?>">
  <div class="form-row">
    <label class="field"><span>Name or phone</span><input type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Asha or 0712…"></label>
    <label class="field"><span>Package</span>
      <select name="package_id"><option value="">All</option>
        <?php foreach ($packages as $p): ?><option value="<?= (int) $p['id'] ?>" <?= $filters['pkg'] === (int) $p['id'] ? 'selected' : '' ?>><?= e($p['label_en']) ?></option><?php endforeach; ?>
      </select></label>
    <label class="field"><span>Status</span>
      <select name="status"><option value="">All</option>
        <?php foreach (['issued' => 'Issued', 'out_of_stock' => 'Out of stock', 'pending' => 'Pending', 'failed' => 'Failed'] as $k => $v): ?>
          <option value="<?= $k ?>" <?= $filters['status'] === $k ? 'selected' : '' ?>><?= $v ?></option>
        <?php endforeach; ?>
      </select></label>
    <label class="field"><span>From</span><input type="date" name="from" value="<?= e($filters['from']) ?>"></label>
    <label class="field"><span>To</span><input type="date" name="to" value="<?= e($filters['to']) ?>"></label>
    <button class="btn btn-ghost" type="submit">Search</button>
  </div>
</form>

<p class="muted"><?= number_format($total) ?> record(s). Voucher codes are masked<?= $canReveal ? '; “Show” is logged in the audit log' : '' ?>.</p>
<div class="table-wrap">
  <table>
    <thead><tr><th>#</th><th>Requested</th><th>Customer</th><th>Phone</th><th>Package</th><th class="num">Amount</th><th>Status</th><th>Voucher</th><?php if ($canReveal): ?><th></th><?php endif; ?></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= (int) $r['id'] ?></td>
        <td><?= e($r['created_at']) ?></td>
        <td><?= e($r['full_name']) ?></td>
        <td><?= e(PhoneNormalizer::display($r['phone_e164'])) ?></td>
        <td><?= e($r['label_en']) ?></td>
        <td class="num"><?= number_format((int) $r['amount_tzs']) ?></td>
        <td><span class="badge <?= e($r['status']) ?>"><?= e(str_replace('_', ' ', $r['status'])) ?></span></td>
        <td class="mono"><?= e($r['code_hint'] ?? '—') ?></td>
        <?php if ($canReveal): ?>
        <td>
          <?php if ($r['status'] === 'issued'): ?>
          <form method="post" action="<?= e(url('/admin/acquisitions/' . (int) $r['id'] . '/reveal')) ?>" class="inline">
            <?= csrf_field() ?><button class="btn btn-ghost btn-small" type="submit">Show</button>
          </form>
          <?php endif; ?>
        </td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="9" class="muted">No matching records.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<div class="pager">
  <?php if ($page > 1): ?><a class="btn btn-ghost btn-small" href="<?= e($qs(['page' => $page - 1])) ?>">← Newer</a><?php endif; ?>
  <span>Page <?= $page ?> of <?= $pages ?></span>
  <?php if ($page < $pages): ?><a class="btn btn-ghost btn-small" href="<?= e($qs(['page' => $page + 1])) ?>">Older →</a><?php endif; ?>
</div>
