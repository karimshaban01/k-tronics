<?php use App\Services\PhoneNormalizer; ?>
<h1>Dashboard</h1>

<div class="grid" style="margin-bottom:12px">
  <div class="stat"><div class="k">Issued today</div><div class="v"><?= number_format((int) $totals['today']) ?></div><div class="s">package value <?= e(tzs((int) $totals['value_today'])) ?></div></div>
  <div class="stat"><div class="k">Issued last 7 days</div><div class="v"><?= number_format((int) $totals['week']) ?></div></div>
  <div class="stat"><div class="k">Issued all time</div><div class="v"><?= number_format((int) $totals['total']) ?></div></div>
  <div class="stat <?= (int) $totals['missed_week'] > 0 ? 'low' : '' ?>"><div class="k">Out-of-stock requests (7 days)</div><div class="v"><?= number_format((int) $totals['missed_week']) ?></div></div>
</div>

<h2>Stock by package</h2>
<?php require __DIR__ . '/_stockcards.php'; ?>

<h2>Latest requests</h2>
<div class="table-wrap">
  <table>
    <thead><tr><th>Time</th><th>Customer</th><th>Phone</th><th>Package</th><th>Status</th><th>Voucher</th></tr></thead>
    <tbody>
    <?php foreach ($recent as $r): ?>
      <tr>
        <td><?= e($r['created_at']) ?></td>
        <td><?= e($r['full_name']) ?></td>
        <td><?= e(PhoneNormalizer::display($r['phone_e164'])) ?></td>
        <td><?= e($r['label_en']) ?></td>
        <td><span class="badge <?= e($r['status']) ?>"><?= e(str_replace('_', ' ', $r['status'])) ?></span></td>
        <td class="mono"><?= e($r['code_hint'] ?? '—') ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$recent): ?><tr><td colspan="6" class="muted">No requests yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
