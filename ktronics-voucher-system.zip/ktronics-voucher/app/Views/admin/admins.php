<h1>Admin users</h1>
<p class="muted"><strong>Owners</strong> manage packages, rolls, users, the audit log and can view full voucher codes. <strong>Operators</strong> import rolls and view stock and masked issuance history.</p>
<div class="table-wrap">
  <table>
    <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last sign-in</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($admins as $a): ?>
      <tr>
        <td><?= e($a['name']) ?></td>
        <td><?= e($a['email']) ?></td>
        <td><?= e($a['role']) ?></td>
        <td><span class="badge <?= (int) $a['active'] ? 'active' : 'disabled' ?>"><?= (int) $a['active'] ? 'active' : 'disabled' ?></span></td>
        <td><?= e($a['last_login_at'] ?? 'never') ?></td>
        <td>
          <?php if ((int) $a['id'] !== (int) $admin['id']): ?>
          <form method="post" action="<?= e(url('/admin/admins/' . (int) $a['id'] . '/toggle')) ?>" class="inline">
            <?= csrf_field() ?>
            <button class="btn <?= (int) $a['active'] ? 'btn-danger' : 'btn-ghost' ?> btn-small" type="submit"><?= (int) $a['active'] ? 'Disable' : 'Enable' ?></button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<h2>Add admin</h2>
<form class="panel" method="post" action="<?= e(url('/admin/admins')) ?>">
  <?= csrf_field() ?>
  <div class="form-row">
    <label class="field"><span>Name</span><input type="text" name="name" maxlength="100" required></label>
    <label class="field"><span>Email</span><input type="email" name="email" maxlength="190" required></label>
    <label class="field"><span>Role</span><select name="role"><option value="operator">Operator</option><option value="owner">Owner</option></select></label>
    <label class="field"><span>Temporary password (10+ chars)</span><input type="password" name="password" minlength="10" autocomplete="new-password" required></label>
  </div>
  <div class="actions"><button class="btn btn-ghost btn-small" type="submit">Create admin</button></div>
</form>
