<h1>Import voucher roll</h1>

<div class="panel">
  <p style="margin-top:0">Upload a pfSense voucher-roll export (the <code>#</code> header lines plus one code per line) or a clean CSV with a
  <code>voucher_code</code> column (optional <code>package_id</code>, <code>expiry</code>). You will see a preview before anything is stored.</p>
  <div class="alert alert-info" style="margin-bottom:0">
    One pfSense roll has one fixed validity. Pick the package whose duration matches the roll's
    <strong>minutes per ticket</strong> setting in pfSense — this app cannot change a voucher's real duration.
    The roll number in the file (e.g. “Roll 500”) does not tell you its duration or price.
  </div>
</div>

<form class="panel" method="post" action="<?= e(url('/admin/rolls/import/preview')) ?>" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <div class="form-row">
    <label class="field"><span>Package for this roll</span>
      <select name="package_id" required>
        <option value="">— choose —</option>
        <?php foreach ($packages as $p): ?>
          <option value="<?= (int) $p['id'] ?>" <?= (int) ($old['package_id'] ?? 0) === (int) $p['id'] ? 'selected' : '' ?>>
            <?= e($p['label_en']) ?> · <?= e(tzs((int) $p['price_tzs'])) ?> · <?= (int) $p['duration_days'] ?> day(s)<?= (int) $p['active'] ? '' : ' (inactive)' ?>
          </option>
        <?php endforeach; ?>
      </select></label>
    <label class="field"><span>Roll label (optional)</span>
      <input type="text" name="label" maxlength="100" value="<?= e($old['label'] ?? '') ?>" placeholder="e.g. Daily – roll 500 – Nov 2026"></label>
    <label class="field"><span>Notes (optional)</span>
      <input type="text" name="notes" maxlength="255" value="<?= e($old['notes'] ?? '') ?>" placeholder="site, zone, who exported it"></label>
  </div>
  <label class="field" style="margin-top:14px"><span>CSV file (max <?= (int) $maxKb ?> KB)</span>
    <input type="file" name="csv" accept=".csv,.txt,text/csv,text/plain" required></label>
  <label style="display:flex;gap:10px;align-items:flex-start;margin:6px 0 4px">
    <input type="checkbox" name="confirm_mapping" value="1" required style="margin-top:4px">
    <span>I confirmed in pfSense that this roll's validity matches the selected package.</span>
  </label>
  <div class="actions"><button class="btn btn-primary" style="width:auto" type="submit" data-loading="Reading file…">Upload &amp; preview</button></div>
</form>
