<h1>Not allowed</h1>
<p class="muted">This page needs the owner role.</p>
<a class="btn btn-ghost" href="<?= e(url('/admin')) ?>">Back to dashboard</a>
