<section class="card login-card">
  <img src="<?= e(asset('img/brand-logo.png')) ?>" alt="Nyikalabs" style="height:44px;border-radius:6px;margin-bottom:12px">
  <h1>Admin sign in</h1>
  <p class="muted">K-TRONICS voucher stock and issuance</p>
  <?php foreach ($flash as $f): ?>
    <div class="alert alert-<?= e($f['type']) ?>" role="alert"><?= e($f['message']) ?></div>
  <?php endforeach; ?>
  <form method="post" action="<?= e(url('/admin/login')) ?>">
    <?= csrf_field() ?>
    <label class="field"><span>Email</span>
      <input type="email" name="email" value="<?= e($email) ?>" autocomplete="username" required autofocus></label>
    <label class="field"><span>Password</span>
      <input type="password" name="password" autocomplete="current-password" required></label>
    <button class="btn btn-primary" type="submit" data-loading="Signing in…">Sign in</button>
  </form>
</section>
