<?php use App\Services\PhoneNormalizer; ?>
<h1>Voucher code</h1>
<div class="panel">
  <p class="muted" style="margin-top:0">Request #<?= (int) $row['id'] ?> · <?= e($row['created_at']) ?> · <?= e($row['full_name']) ?> · <?= e(PhoneNormalizer::display($row['phone_e164'])) ?> · <?= e($row['label_en']) ?></p>
  <div class="code-box" style="max-width:420px">
    <output id="voucher-code" class="code"><?= e($code) ?></output>
    <button type="button" class="btn btn-copy" data-copy="#voucher-code" data-copied="Copied" data-failed="Select and copy manually">Copy</button>
  </div>
  <p class="muted">This view was recorded in the audit log. Share the code only with the verified customer.</p>
  <a class="btn btn-ghost" href="<?= e(url('/admin/acquisitions')) ?>">Back to list</a>
</div>
