<h1>Packages</h1>
<div class="alert alert-info">Each package should only receive vouchers from pfSense rolls with the same validity. Changing a duration here does not change vouchers already in stock.</div>

<?php foreach ($packages as $p): ?>
<form class="panel" method="post" action="<?= e(url('/admin/packages')) ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
  <div class="form-row">
    <label class="field"><span>Kiswahili label</span><input type="text" name="label" value="<?= e($p['label']) ?>" maxlength="60" required <?= $canEdit ? '' : 'disabled' ?>></label>
    <label class="field"><span>English label</span><input type="text" name="label_en" value="<?= e($p['label_en']) ?>" maxlength="60" required <?= $canEdit ? '' : 'disabled' ?>></label>
    <label class="field"><span>Price (TZS)</span><input type="number" name="price_tzs" value="<?= (int) $p['price_tzs'] ?>" min="0" step="1" required <?= $canEdit ? '' : 'disabled' ?>></label>
    <label class="field"><span>Duration (days)</span><input type="number" name="duration_days" value="<?= (int) $p['duration_days'] ?>" min="1" max="366" required <?= $canEdit ? '' : 'disabled' ?>></label>
    <label class="field"><span>Order</span><input type="number" name="display_order" value="<?= (int) $p['display_order'] ?>" <?= $canEdit ? '' : 'disabled' ?>></label>
    <label style="display:flex;gap:8px;align-items:center;min-height:48px"><input type="checkbox" name="active" value="1" <?= (int) $p['active'] ? 'checked' : '' ?> <?= $canEdit ? '' : 'disabled' ?>> Shown to customers</label>
  </div>
  <div class="actions" style="align-items:center">
    <?php if ($canEdit): ?><button class="btn btn-ghost btn-small" type="submit">Save</button><?php endif; ?>
    <span class="muted"><?= number_format((int) $p['available']) ?> available · <?= number_format((int) $p['issued_total']) ?> issued</span>
  </div>
</form>
<?php endforeach; ?>

<?php if ($canEdit): ?>
<h2>Add package</h2>
<form class="panel" method="post" action="<?= e(url('/admin/packages')) ?>">
  <?= csrf_field() ?>
  <div class="form-row">
    <label class="field"><span>Kiswahili label</span><input type="text" name="label" maxlength="60" required placeholder="Saa 12"></label>
    <label class="field"><span>English label</span><input type="text" name="label_en" maxlength="60" required placeholder="12 hours"></label>
    <label class="field"><span>Price (TZS)</span><input type="number" name="price_tzs" min="0" step="1" required></label>
    <label class="field"><span>Duration (days)</span><input type="number" name="duration_days" min="1" max="366" required></label>
    <label class="field"><span>Order</span><input type="number" name="display_order" value="10"></label>
    <label style="display:flex;gap:8px;align-items:center;min-height:48px"><input type="checkbox" name="active" value="1" checked> Shown to customers</label>
  </div>
  <div class="actions"><button class="btn btn-ghost btn-small" type="submit">Create package</button></div>
</form>
<?php endif; ?>
