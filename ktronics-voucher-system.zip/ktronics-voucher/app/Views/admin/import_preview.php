<?php
$valid = count($parsed['codes']);
$invalid = count($parsed['invalid']);
?>
<h1>Import preview</h1>

<div class="grid" style="margin-bottom:12px">
  <div class="stat"><div class="k">Voucher rows read</div><div class="v"><?= number_format($parsed['rows']) ?></div><div class="s">format: <?= e($parsed['format'] === 'pfsense' ? 'pfSense roll export' : 'CSV with header') ?></div></div>
  <div class="stat <?= $newCount > 0 ? '' : 'empty' ?>"><div class="k">New codes to add</div><div class="v"><?= number_format($newCount) ?></div></div>
  <div class="stat <?= ($parsed['dup_in_file'] + $existing) > 0 ? 'low' : '' ?>"><div class="k">Duplicates (skipped)</div><div class="v"><?= number_format($parsed['dup_in_file'] + $existing) ?></div><div class="s"><?= (int) $parsed['dup_in_file'] ?> in file · <?= (int) $existing ?> already stored</div></div>
  <div class="stat <?= $invalid > 0 ? 'low' : '' ?>"><div class="k">Rejected rows</div><div class="v"><?= number_format($invalid) ?></div></div>
</div>

<div class="panel">
  <div class="form-row">
    <div><div class="muted">File</div><strong><?= e($filename) ?></strong></div>
    <div><div class="muted">Package</div><strong><?= e($package['label_en']) ?> · <?= e(tzs((int) $package['price_tzs'])) ?> · <?= (int) $package['duration_days'] ?> day(s)</strong></div>
    <div><div class="muted">Roll label</div><strong><?= e($label) ?></strong></div>
    <div><div class="muted">pfSense roll no.</div><strong><?= $parsed['roll_no'] !== null ? (int) $parsed['roll_no'] : 'not stated' ?></strong></div>
  </div>
  <?php if ($parsed['meta']): ?>
    <h2 style="margin-top:16px">Header / metadata</h2>
    <ul class="meta-list"><?php foreach ($parsed['meta'] as $m): ?><li><?= e($m) ?></li><?php endforeach; ?></ul>
  <?php endif; ?>
  <?php if ($samples): ?>
    <h2>Sample codes (masked)</h2>
    <p class="mono"><?= e(implode('   ', $samples)) ?></p>
  <?php endif; ?>
</div>

<?php if ($invalid): ?>
  <h2>Rejected rows</h2>
  <div class="table-wrap" style="max-height:280px;overflow:auto">
    <table>
      <thead><tr><th>Line</th><th>Value (masked)</th><th>Reason</th></tr></thead>
      <tbody>
      <?php foreach (array_slice($parsed['invalid'], 0, 200) as $r): ?>
        <tr><td><?= (int) $r['line'] ?></td><td class="mono"><?= e($r['sample']) ?></td><td><?= e($r['reason']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($invalid > 200): ?><p class="muted">Showing first 200 of <?= $invalid ?>.</p><?php endif; ?>
<?php endif; ?>

<div class="actions">
  <?php if ($newCount > 0): ?>
  <form method="post" action="<?= e(url('/admin/rolls/import/commit')) ?>" class="inline">
    <?= csrf_field() ?>
    <input type="hidden" name="token" value="<?= e(\App\Core\Session::get('pending_import')['token'] ?? '') ?>">
    <button class="btn btn-primary" style="width:auto" type="submit" data-loading="Importing…">Import <?= number_format($newCount) ?> codes into “<?= e($package['label_en']) ?>”</button>
  </form>
  <?php endif; ?>
  <form method="post" action="<?= e(url('/admin/rolls/import/cancel')) ?>" class="inline">
    <?= csrf_field() ?>
    <button class="btn btn-ghost" type="submit">Cancel</button>
  </form>
</div>
