<h1>My account</h1>
<form class="panel" method="post" action="<?= e(url('/admin/account/password')) ?>" style="max-width:480px">
  <?= csrf_field() ?>
  <label class="field"><span>Current password</span><input type="password" name="current_password" autocomplete="current-password" required></label>
  <label class="field"><span>New password (10+ characters)</span><input type="password" name="new_password" minlength="10" autocomplete="new-password" required></label>
  <label class="field"><span>Confirm new password</span><input type="password" name="confirm_password" minlength="10" autocomplete="new-password" required></label>
  <button class="btn btn-ghost" type="submit">Change password</button>
</form>
