<?php $isOwner = ($admin['role'] ?? '') === 'owner'; ?>
<h1>Stock &amp; rolls</h1>
<?php require __DIR__ . '/_stockcards.php'; ?>

<h2>Imported rolls</h2>
<p class="muted">Only <em>active</em> rolls are used for issuing. Disable a roll if its pfSense validity turns out not to match its package.</p>
<div class="table-wrap">
  <table>
    <thead><tr>
      <th>#</th><th>Label</th><th>Package</th><th>pfSense roll</th><th>File</th><th>Imported</th>
      <th class="num">Stored</th><th class="num">Available</th><th class="num">Issued</th><th class="num">Dup.</th><th class="num">Invalid</th><th>Status</th><?php if ($isOwner): ?><th></th><?php endif; ?>
    </tr></thead>
    <tbody>
    <?php foreach ($rolls as $r): ?>
      <tr>
        <td><?= (int) $r['id'] ?></td>
        <td><?= e($r['label']) ?></td>
        <td><?= e($r['package_label']) ?></td>
        <td><?= $r['pfsense_roll_no'] !== null ? (int) $r['pfsense_roll_no'] : '—' ?></td>
        <td><?= e($r['source_filename']) ?></td>
        <td><?= e($r['imported_at']) ?><br><span class="muted"><?= e($r['imported_by_name']) ?></span></td>
        <td class="num"><?= number_format((int) $r['total_count']) ?></td>
        <td class="num"><?= number_format((int) $r['available']) ?></td>
        <td class="num"><?= number_format((int) $r['issued']) ?></td>
        <td class="num"><?= number_format((int) $r['duplicate_count']) ?></td>
        <td class="num"><?= number_format((int) $r['invalid_count']) ?></td>
        <td><span class="badge <?= e($r['status']) ?>"><?= e($r['status']) ?></span></td>
        <?php if ($isOwner): ?>
        <td>
          <form method="post" action="<?= e(url('/admin/rolls/' . (int) $r['id'] . '/status')) ?>" class="inline">
            <?= csrf_field() ?>
            <?php if ($r['status'] === 'active'): ?>
              <input type="hidden" name="status" value="disabled">
              <button class="btn btn-danger btn-small" data-confirm="Stop issuing vouchers from this roll?">Disable</button>
            <?php else: ?>
              <input type="hidden" name="status" value="active">
              <button class="btn btn-ghost btn-small">Enable</button>
            <?php endif; ?>
          </form>
        </td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rolls): ?><tr><td colspan="13" class="muted">No rolls yet — <a href="<?= e(url('/admin/rolls/import')) ?>">import one</a>.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
