<div class="grid">
  <?php foreach ($packages as $p):
      $a = (int) $p['available'];
      $cls = $a === 0 ? 'empty' : ($a < \App\Controllers\AdminController::LOW_STOCK ? 'low' : ''); ?>
    <div class="stat <?= $cls ?>">
      <div class="k"><?= e($p['label_en']) ?> · <?= e(tzs((int) $p['price_tzs'])) ?> · <?= (int) $p['duration_days'] ?>d</div>
      <div class="v"><?= number_format($a) ?></div>
      <div class="s">available · <?= (int) $p['issued_today'] ?> issued today<?= $a === 0 ? ' · OUT OF STOCK' : ($cls === 'low' ? ' · low' : '') ?></div>
    </div>
  <?php endforeach; ?>
</div>
