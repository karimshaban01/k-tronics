<h1>Audit log</h1>
<div class="table-wrap">
  <table>
    <thead><tr><th>Time</th><th>Admin</th><th>Action</th><th>Target</th><th>Details</th><th>IP</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= e($r['created_at']) ?></td>
        <td><?= e($r['admin_name'] ?? '—') ?></td>
        <td><?= e(str_replace('_', ' ', $r['action'])) ?></td>
        <td><?= e(trim(($r['target_type'] ?? '') . ' ' . ($r['target_id'] ?? ''))) ?></td>
        <td class="mono" style="white-space:normal;max-width:420px;font-size:12px"><?= e($r['metadata_json'] ?? '') ?></td>
        <td><?= e($r['ip']) ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="6" class="muted">Nothing logged yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<div class="pager">
  <?php if ($page > 1): ?><a class="btn btn-ghost btn-small" href="<?= e(url('/admin/audit', ['page' => $page - 1])) ?>">← Newer</a><?php endif; ?>
  <span>Page <?= $page ?> of <?= $pages ?></span>
  <?php if ($page < $pages): ?><a class="btn btn-ghost btn-small" href="<?= e(url('/admin/audit', ['page' => $page + 1])) ?>">Older →</a><?php endif; ?>
</div>
