<?php
use App\Core\Lang;
$lang = Lang::current();
?>
<section class="card result">
  <h1><?= e(t('your_voucher')) ?></h1>
  <p class="muted"><?= e(t('hello', ['name' => $firstName])) ?></p>

  <dl class="summary">
    <div><dt><?= e(t('package')) ?></dt><dd><?= e($lang === 'en' ? $package['label_en'] : $package['label']) ?></dd></div>
    <div><dt><?= e(t('duration')) ?></dt><dd><?= e(duration_label((int) $package['duration_days'], $lang)) ?></dd></div>
    <div><dt><?= e(t('price')) ?></dt><dd><?= e(tzs((int) $package['price_tzs'])) ?></dd></div>
  </dl>

  <div class="code-box">
    <output id="voucher-code" class="code" aria-live="polite"><?= e($code) ?></output>
    <button type="button" class="btn btn-copy" data-copy="#voucher-code"
            data-copied="<?= e(t('copied')) ?>" data-failed="<?= e(t('copy_failed')) ?>"><?= e(t('copy')) ?></button>
  </div>

  <p class="instructions"><?= e(t('how_to_use')) ?></p>
  <p class="warning"><?= e(t('save_warning')) ?></p>

  <a class="btn btn-primary" href="<?= e($returnUrl) ?>" rel="noreferrer"><?= e(t('back_to_portal')) ?></a>
</section>
