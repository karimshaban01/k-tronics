<?php
use App\Core\Lang;
$lang = Lang::current();
$selected = (int) ($old['package_id'] ?? 0);
if ($selected === 0) {
    foreach ($packages as $p) { if ($p['available'] > 0) { $selected = (int) $p['id']; break; } }
}
?>
<section class="card">
  <h1><?= e(t('headline')) ?></h1>
  <p class="muted"><?= e(t('subhead')) ?></p>

  <?php foreach ($flash as $f): ?>
    <div class="alert alert-<?= e($f['type']) ?>" role="alert"><?= e($f['message']) ?></div>
  <?php endforeach; ?>

  <form id="form" method="post" action="<?= e(url('/acquisitions')) ?>" class="acq-form" novalidate>
    <?= csrf_field() ?>
    <input type="hidden" name="request_token" value="<?= e($requestToken) ?>">

    <fieldset>
      <legend><?= e(t('step_package')) ?></legend>
      <div class="packages">
        <?php foreach ($packages as $p):
            $soldOut = $p['available'] <= 0; ?>
          <label class="pkg<?= $soldOut ? ' is-out' : '' ?>">
            <input type="radio" name="package_id" value="<?= (int) $p['id'] ?>"
                   <?= $selected === (int) $p['id'] && !$soldOut ? 'checked' : '' ?>
                   <?= $soldOut ? 'disabled' : '' ?> required>
            <span class="pkg-body">
              <span class="pkg-name"><?= e($lang === 'en' ? $p['label_en'] : $p['label']) ?></span>
              <span class="pkg-price"><?= e(tzs((int) $p['price_tzs'])) ?></span>
              <span class="pkg-meta">
                <?= e(duration_label((int) $p['duration_days'], $lang)) ?> ·
                <span class="<?= $soldOut ? 'out' : 'ok' ?>"><?= e($soldOut ? t('out_of_stock') : t('in_stock')) ?></span>
              </span>
            </span>
          </label>
        <?php endforeach; ?>
      </div>
    </fieldset>

    <fieldset>
      <legend><?= e(t('step_details')) ?></legend>
      <label class="field">
        <span><?= e(t('full_name')) ?></span>
        <input type="text" name="full_name" value="<?= e($old['full_name'] ?? '') ?>" placeholder="<?= e(t('full_name_ph')) ?>"
               autocomplete="name" minlength="3" maxlength="100" required>
      </label>
      <label class="field">
        <span><?= e(t('phone')) ?></span>
        <input type="tel" name="phone" value="<?= e($old['phone'] ?? '') ?>" placeholder="<?= e(t('phone_ph')) ?>"
               autocomplete="tel" inputmode="tel" maxlength="20" required>
      </label>
    </fieldset>

    <button type="submit" class="btn btn-primary" data-loading="<?= e(t('issuing')) ?>"><?= e(t('get_voucher')) ?></button>
    <p class="fine"><?= e(t('privacy_notice')) ?> <a href="<?= e(url('/privacy')) ?>"><?= e(t('privacy_link')) ?></a></p>
  </form>
</section>
