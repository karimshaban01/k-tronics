<section class="card">
  <h1><?= e(t('privacy_title')) ?></h1>
  <p><?= e(t('privacy_body', ['days' => $retentionDays])) ?></p>
  <a class="btn btn-ghost" href="<?= e(url('/')) ?>"><?= e(t('back')) ?></a>
</section>
