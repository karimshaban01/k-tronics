<?php
$items = [
    'dashboard'    => ['/admin', 'Dashboard', false],
    'stock'        => ['/admin/stock', 'Stock & rolls', false],
    'import'       => ['/admin/rolls/import', 'Import roll', false],
    'acquisitions' => ['/admin/acquisitions', 'Issued vouchers', false],
    'packages'     => ['/admin/packages', 'Packages', false],
    'admins'       => ['/admin/admins', 'Admin users', true],
    'audit'        => ['/admin/audit', 'Audit log', true],
    'account'      => ['/admin/account', 'My account', false],
];
$isOwner = ($admin['role'] ?? '') === 'owner';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow">
  <title><?= e($title ?? 'Admin') ?> · K-TRONICS Admin</title>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body class="admin">
<?php if (!empty($admin)): ?>
  <div class="admin-shell">
    <aside class="side">
      <img src="<?= e(asset('img/brand-logo.png')) ?>" alt="Nyikalabs">
      <nav>
        <?php foreach ($items as $key => [$href, $label, $ownerOnly]):
            if ($ownerOnly && !$isOwner) continue; ?>
          <a href="<?= e(url($href)) ?>" class="<?= ($nav ?? '') === $key ? 'active' : '' ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
      </nav>
      <div class="who">
        <div><?= e($admin['name']) ?> · <?= e($admin['role']) ?></div>
        <form method="post" action="<?= e(url('/admin/logout')) ?>">
          <?= csrf_field() ?>
          <button class="btn btn-ghost btn-small" type="submit">Sign out</button>
        </form>
      </div>
    </aside>
    <main class="main">
      <?php foreach (($flash ?? []) as $f): ?>
        <div class="alert alert-<?= e($f['type']) ?>" role="alert"><?= e($f['message']) ?></div>
      <?php endforeach; ?>
      <?= $content ?>
    </main>
  </div>
<?php else: ?>
  <main class="main"><?= $content ?></main>
<?php endif; ?>
  <script src="<?= e(asset('js/app.js')) ?>" defer></script>
</body>
</html>
