<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow">
  <title><?= e($title ?? 'Admin') ?> · K-TRONICS Admin</title>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body class="admin">
  <div class="stars" aria-hidden="true"></div>
  <main class="shell"><?= $content ?></main>
</body>
</html>
