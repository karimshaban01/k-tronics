<?php
use App\Core\Lang;
$lang = Lang::current();
?><!doctype html>
<html lang="<?= e($lang) ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="robots" content="noindex">
  <meta name="theme-color" content="#080D1D">
  <title><?= e($title ?? t('page_title')) ?> · K-TRONICS</title>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body class="portal">
  <div class="stars" aria-hidden="true"></div>
  <main class="shell">
    <header class="brand">
      <img src="<?= e(asset('img/brand-logo.png')) ?>" alt="Nyikalabs" width="116" height="55">
      <a class="lang" href="<?= e((parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/') . '?lang=' . ($lang === 'sw' ? 'en' : 'sw')) ?>"><?= e(t('lang_switch')) ?></a>
    </header>
    <?= $content ?>
    <footer class="foot">K-TRONICS Wi-Fi · <a href="<?= e(url('/privacy')) ?>"><?= e(t('privacy_link')) ?></a></footer>
  </main>
  <script src="<?= e(asset('js/app.js')) ?>" defer></script>
</body>
</html>
