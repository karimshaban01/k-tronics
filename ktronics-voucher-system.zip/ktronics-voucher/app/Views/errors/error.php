<section class="card">
  <h1><?= e((string) ($code ?? 'Error')) ?></h1>
  <p class="muted"><?= e($message ?? '') ?></p>
  <a class="btn btn-ghost" href="<?= e(url('/')) ?>"><?= e(t('back')) ?></a>
</section>
