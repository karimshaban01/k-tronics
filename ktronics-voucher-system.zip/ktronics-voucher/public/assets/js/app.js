(function () {
  'use strict';

  // Disable submit buttons after the first tap and show a loading label.
  document.querySelectorAll('form').forEach(function (form) {
    form.addEventListener('submit', function () {
      var btn = form.querySelector('button[type=submit][data-loading]');
      if (btn) {
        // Delay the disable so the click still submits on every browser.
        setTimeout(function () {
          btn.disabled = true;
          btn.classList.add('is-loading');
          btn.textContent = btn.getAttribute('data-loading');
        }, 0);
      }
    });
  });

  // Confirm dangerous admin actions.
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (ev) {
      if (!window.confirm(el.getAttribute('data-confirm'))) { ev.preventDefault(); }
    });
  });

  // Copy voucher code. Clipboard API needs HTTPS, and captive-portal browsers often
  // lack it, so fall back to a selected textarea + execCommand.
  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '-1000px';
    document.body.appendChild(ta);
    ta.select();
    ta.setSelectionRange(0, text.length);
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    return ok;
  }

  document.querySelectorAll('[data-copy]').forEach(function (btn) {
    var original = btn.textContent;
    btn.addEventListener('click', function () {
      var target = document.querySelector(btn.getAttribute('data-copy'));
      if (!target) { return; }
      var text = target.textContent.trim();
      var done = function (ok) {
        btn.textContent = ok ? btn.getAttribute('data-copied') : btn.getAttribute('data-failed');
        btn.classList.toggle('is-done', ok);
        if (!ok) {
          var range = document.createRange();
          range.selectNodeContents(target);
          var sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(range);
        }
        setTimeout(function () { btn.textContent = original; btn.classList.remove('is-done'); }, 2500);
      };
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(fallbackCopy(text)); });
      } else {
        done(fallbackCopy(text));
      }
    });
  });
})();
