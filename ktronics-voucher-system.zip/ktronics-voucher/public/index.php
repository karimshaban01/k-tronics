<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

use App\Controllers\AdminController;
use App\Controllers\AuthController;
use App\Controllers\ImportController;
use App\Controllers\PortalController;
use App\Core\Config;
use App\Core\Lang;
use App\Core\Router;
use App\Core\Session;

// Security headers (no inline scripts are used anywhere).
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");
if (is_https()) {
    header('Strict-Transport-Security: max-age=31536000');
}
if (Config::get('app.force_https') && !is_https()) {
    redirect('https://' . ($_SERVER['HTTP_HOST'] ?? '') . ($_SERVER['REQUEST_URI'] ?? '/'), 301);
}

Session::start();
Lang::init();

$portal = new PortalController();
$auth   = new AuthController();
$admin  = new AdminController();
$import = new ImportController();

$r = new Router();
// Public portal
$r->get('/',                                [$portal, 'home']);
$r->post('/acquisitions',                   [$portal, 'acquire']);
$r->get('/acquisitions/{ref}/result',       [$portal, 'result']);
$r->get('/privacy',                         [$portal, 'privacy']);
// Admin
$r->get('/admin/login',                     [$auth, 'showLogin']);
$r->post('/admin/login',                    [$auth, 'login']);
$r->post('/admin/logout',                   [$auth, 'logout']);
$r->get('/admin',                           [$admin, 'dashboard']);
$r->get('/admin/stock',                     [$admin, 'stock']);
$r->post('/admin/rolls/{id}/status',        [$admin, 'rollStatus']);
$r->get('/admin/rolls/import',              [$import, 'form']);
$r->post('/admin/rolls/import/preview',     [$import, 'preview']);
$r->post('/admin/rolls/import/commit',      [$import, 'commit']);
$r->post('/admin/rolls/import/cancel',      [$import, 'cancel']);
$r->get('/admin/acquisitions',              [$admin, 'acquisitions']);
$r->post('/admin/acquisitions/{id}/reveal', [$admin, 'reveal']);
$r->get('/admin/packages',                  [$admin, 'packages']);
$r->post('/admin/packages',                 [$admin, 'savePackage']);
$r->get('/admin/admins',                    [$admin, 'admins']);
$r->post('/admin/admins',                   [$admin, 'saveAdmin']);
$r->post('/admin/admins/{id}/toggle',       [$admin, 'toggleAdmin']);
$r->get('/admin/audit',                     [$admin, 'audit']);
$r->get('/admin/account',                   [$admin, 'account']);
$r->post('/admin/account/password',         [$admin, 'changePassword']);

// Path relative to the folder index.php is served from.
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
if ($scriptDir !== '' && str_starts_with($path, $scriptDir)) {
    $path = substr($path, strlen($scriptDir)) ?: '/';
}

try {
    $r->dispatch($_SERVER['REQUEST_METHOD'] ?? 'GET', $path);
} catch (\Throwable $e) {
    error_log('[ktronics] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
    }
    if (Config::get('app.env') === 'development') {
        echo '<pre>' . e((string) $e) . '</pre>';
    } else {
        \App\Core\View::render('errors/error', ['code' => 500, 'message' => Lang::current() === 'en'
            ? 'Something went wrong. Please try again or ask an attendant.'
            : 'Kuna hitilafu. Tafadhali jaribu tena au muulize mhudumu.']);
    }
}
