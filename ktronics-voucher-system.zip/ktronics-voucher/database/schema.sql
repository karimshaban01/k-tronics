-- K-TRONICS Voucher Acquisition System — MySQL 5.7+/8 or MariaDB 10.3+ schema
-- All tables use InnoDB (required for transactions and row locking).

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS admins (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(100) NOT NULL,
  email          VARCHAR(190) NOT NULL,
  password_hash  VARCHAR(255) NOT NULL,
  role           ENUM('owner','operator') NOT NULL DEFAULT 'operator',
  active         TINYINT(1) NOT NULL DEFAULT 1,
  created_at     DATETIME NOT NULL,
  last_login_at  DATETIME NULL,
  UNIQUE KEY uq_admins_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS packages (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  label          VARCHAR(60) NOT NULL,          -- Kiswahili label
  label_en       VARCHAR(60) NOT NULL,          -- English label
  price_tzs      INT UNSIGNED NOT NULL,
  duration_days  SMALLINT UNSIGNED NOT NULL,
  active         TINYINT(1) NOT NULL DEFAULT 1,
  display_order  SMALLINT NOT NULL DEFAULT 0,
  created_at     DATETIME NOT NULL,
  updated_at     DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS voucher_rolls (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  label            VARCHAR(100) NOT NULL,
  source_filename  VARCHAR(255) NOT NULL,
  package_id       INT UNSIGNED NOT NULL,
  pfsense_roll_no  INT UNSIGNED NULL,           -- from the CSV header, informational only
  imported_by      INT UNSIGNED NOT NULL,
  imported_at      DATETIME NOT NULL,
  total_count      INT UNSIGNED NOT NULL DEFAULT 0,  -- codes stored from this roll
  duplicate_count  INT UNSIGNED NOT NULL DEFAULT 0,
  invalid_count    INT UNSIGNED NOT NULL DEFAULT 0,
  status           ENUM('active','disabled') NOT NULL DEFAULT 'active',
  notes            VARCHAR(255) NULL,
  KEY ix_rolls_package (package_id),
  CONSTRAINT fk_rolls_package FOREIGN KEY (package_id) REFERENCES packages(id),
  CONSTRAINT fk_rolls_admin   FOREIGN KEY (imported_by) REFERENCES admins(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS customers (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name   VARCHAR(100) NOT NULL,
  phone_e164  VARCHAR(16) NOT NULL,
  created_at  DATETIME NOT NULL,
  updated_at  DATETIME NOT NULL,
  KEY ix_customers_phone (phone_e164)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vouchers (
  id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  roll_id                   INT UNSIGNED NOT NULL,
  package_id                INT UNSIGNED NOT NULL,
  code_ciphertext           VARBINARY(255) NOT NULL,   -- libsodium secretbox (nonce + ciphertext)
  code_hash                 BINARY(32) NOT NULL,       -- HMAC-SHA256 of the code, for duplicate detection
  code_hint                 VARCHAR(16) NOT NULL,      -- masked form for admin lists, e.g. "ab••••yz"
  status                    ENUM('available','issued','void') NOT NULL DEFAULT 'available',
  issued_to_acquisition_id  BIGINT UNSIGNED NULL,
  issued_at                 DATETIME NULL,
  expires_at                DATETIME NULL,
  created_at                DATETIME NOT NULL,
  UNIQUE KEY uq_vouchers_hash (code_hash),
  KEY ix_vouchers_alloc (package_id, status, id),
  KEY ix_vouchers_roll (roll_id, status),
  CONSTRAINT fk_vouchers_roll    FOREIGN KEY (roll_id) REFERENCES voucher_rolls(id),
  CONSTRAINT fk_vouchers_package FOREIGN KEY (package_id) REFERENCES packages(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS acquisitions (
  id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  public_ref         CHAR(32) NOT NULL,          -- random reference used in the result URL
  request_token      CHAR(32) NOT NULL,          -- one per form load; makes resubmits idempotent
  customer_id        BIGINT UNSIGNED NOT NULL,
  package_id         INT UNSIGNED NOT NULL,
  voucher_id         BIGINT UNSIGNED NULL,
  amount_tzs         INT UNSIGNED NOT NULL,
  status             ENUM('pending','issued','out_of_stock','failed') NOT NULL DEFAULT 'pending',
  client_ip          VARCHAR(45) NULL,
  created_at         DATETIME NOT NULL,
  issued_at          DATETIME NULL,
  portal_return_url  VARCHAR(500) NULL,
  UNIQUE KEY uq_acq_ref (public_ref),
  UNIQUE KEY uq_acq_token (request_token),
  UNIQUE KEY uq_acq_voucher (voucher_id),
  KEY ix_acq_customer (customer_id, created_at),
  KEY ix_acq_created (created_at),
  CONSTRAINT fk_acq_customer FOREIGN KEY (customer_id) REFERENCES customers(id),
  CONSTRAINT fk_acq_package  FOREIGN KEY (package_id) REFERENCES packages(id),
  CONSTRAINT fk_acq_voucher  FOREIGN KEY (voucher_id) REFERENCES vouchers(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
  id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_id       INT UNSIGNED NULL,
  action         VARCHAR(60) NOT NULL,
  target_type    VARCHAR(40) NULL,
  target_id      BIGINT UNSIGNED NULL,
  metadata_json  TEXT NULL,
  ip             VARCHAR(45) NULL,
  created_at     DATETIME NOT NULL,
  KEY ix_audit_created (created_at),
  KEY ix_audit_admin (admin_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
  bucket        VARCHAR(120) NOT NULL PRIMARY KEY,
  hits          INT UNSIGNED NOT NULL,
  window_start  INT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

-- Default package catalogue (edit prices/durations from Admin → Packages).
INSERT INTO packages (label, label_en, price_tzs, duration_days, active, display_order, created_at, updated_at)
SELECT * FROM (
  SELECT 'Siku 1'   AS label, 'Daily'   AS label_en,   500 AS p,  1 AS d, 1 AS a, 1 AS o, NOW() AS c, NOW() AS u UNION ALL
  SELECT 'Siku 2',            '2 days',               1000,      2,      1,      2,      NOW(),     NOW()     UNION ALL
  SELECT 'Wiki 1',            'Weekly',               3000,      7,      1,      3,      NOW(),     NOW()     UNION ALL
  SELECT 'Mwezi 1',           'Monthly',             10000,     30,      1,      4,      NOW(),     NOW()
) seed
WHERE NOT EXISTS (SELECT 1 FROM packages);
